package es.elorrieta.app.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class EmailDetailFragment : Fragment() {

    private lateinit var textView: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.fragment_email_detail, container, false)

        textView = view.findViewById(R.id.textViewEmail)

        return view
    }

    fun mostrarEmail(email: String) {
        textView.text = email
    }
}