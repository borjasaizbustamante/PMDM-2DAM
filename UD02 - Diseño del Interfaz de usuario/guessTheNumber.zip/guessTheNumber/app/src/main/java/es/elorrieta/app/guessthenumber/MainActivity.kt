package es.elorrieta.app.guessthenumber

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    // 4.2 Tries
    private var tries = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 4.1 Random number
        val target = (1..100).random()

        // 4.3 Button Event
        findViewById<Button>(R.id.buttonGuess).setOnClickListener {
            val number = findViewById<EditText>(R.id.editTextGuess).text.toString().toInt()

            // 4.4 Polish
            findViewById<EditText>(R.id.editTextGuess).text.clear()
            if (tries != 0) {
                if (number > target) {
                    findViewById<TextView>(R.id.labelTitlle).text =
                        getString(R.string.number_smaller)
                    tries--
                } else if (number < target) {
                    findViewById<TextView>(R.id.labelTitlle).text =
                        getString(R.string.number_bigger)
                    tries--
                } else {
                    findViewById<TextView>(R.id.labelTitlle).text = getString(R.string.number_equal)
                }
            } else {
                findViewById<TextView>(R.id.labelTitlle).text = getString(R.string.game_over)
            }
        }
    }
}