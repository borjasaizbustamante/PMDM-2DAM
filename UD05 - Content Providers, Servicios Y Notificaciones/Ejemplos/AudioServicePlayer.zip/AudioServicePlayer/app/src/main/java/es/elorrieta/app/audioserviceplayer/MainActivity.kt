package es.elorrieta.app.audioserviceplayer

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import es.elorrieta.app.audioserviceplayer.service.AudioService

class MainActivity : AppCompatActivity() {

    private var isPlaying = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // We dinamically add a button to the view
        val button = Button(this).apply {
            text = "Reproducir"
            setOnClickListener {
                toggleAudio()
            }
        }

        setContentView(button)
    }

    // Send an action to the Service
    private fun toggleAudio() {

        // An intent to the Service
        val intent = Intent(this, AudioService::class.java)

        if (!isPlaying) {
            intent.action = "PLAY"
            startService(intent)
            isPlaying = true
        } else {
            intent.action = "STOP"
            startService(intent)
            isPlaying = false
        }
    }

}