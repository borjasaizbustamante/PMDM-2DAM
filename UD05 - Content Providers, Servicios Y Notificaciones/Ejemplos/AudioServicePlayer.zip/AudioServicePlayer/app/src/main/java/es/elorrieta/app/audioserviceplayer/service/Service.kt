package es.elorrieta.app.audioserviceplayer.service

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import es.elorrieta.app.audioserviceplayer.R

// The service
class AudioService : Service() {

    // The media player
    private var mediaPlayer: MediaPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    // Lifecycle of the Service - onStartCommand
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        // What action do you want me to do?
        when (intent?.action) {
            "PLAY" -> playAudio()
            "STOP" -> stopAudio()
        }

        return START_STICKY
    }

    private fun playAudio() {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, R.raw.audio)
            mediaPlayer?.isLooping = false
        }

        mediaPlayer?.start()
    }

    private fun stopAudio() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    // Lifecycle of the Service - onDestroy
    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }
}