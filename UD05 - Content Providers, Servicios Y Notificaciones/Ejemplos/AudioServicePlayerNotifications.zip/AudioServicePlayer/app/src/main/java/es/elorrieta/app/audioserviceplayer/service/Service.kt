package es.elorrieta.app.audioserviceplayer.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import es.elorrieta.app.audioserviceplayer.MainActivity
import es.elorrieta.app.audioserviceplayer.R

// The service
class AudioService : Service() {

    private var mediaPlayer: MediaPlayer? = null

    // The Channel
    private val channelId = "audio_channel"

    override fun onBind(intent: Intent?): IBinder? = null

    // Lifecycle of the Service - onDestroy
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    // The Notification Channel
    private fun createNotificationChannel() {

        // This is mandatory since the Oreo only!!
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val channel = NotificationChannel(
                channelId,
                "Audio Service",
                NotificationManager.IMPORTANCE_DEFAULT
            )

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun showNotificationOn() {

        val intent = Intent(this, MainActivity::class.java)

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        // Notification: showing the play icon and more...
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Reproduciendo audio")
            .setContentText("El servicio está activo")
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .build()

        // Start the service in foreground
        startForeground(1, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        when (intent?.action) {
            "PLAY" -> {
                playAudio()
                showNotificationOn() // Show the notification!!!
            }
            "STOP" -> {
                stopAudio()
                stopForeground(STOP_FOREGROUND_REMOVE)
            }
        }

        return START_STICKY
    }

    private fun playAudio() {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, R.raw.audio)
            mediaPlayer?.isLooping = false
        }

        mediaPlayer?.start()
    }

    private fun stopAudio() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }
}