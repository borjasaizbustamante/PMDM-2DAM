package es.pruebas.thebestestvideogamekotlin

import android.os.Bundle
import android.widget.CheckBox
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // i es el radiobutton del radiogroup que se ha pulsado
        findViewById<RadioGroup>(R.id.radioGroup).setOnCheckedChangeListener { _,
                                                                               i ->
            when (i) {
                R.id.radioButtonFallout -> findViewById<TextView>(R.id.textView2).text =
                    (getString(R.string.text_response) + " Fallout")
                R.id.radioButtonLol -> findViewById<TextView>(R.id.textView2).text =
                    (getString(R.string.text_response) + " Lol")
                R.id.radioButtonFortnite -> findViewById<TextView>(R.id.textView2).text =
                    (getString(R.string.text_response) + " Fortnite")
                R.id.radioButtonTF2 -> findViewById<TextView>(R.id.textView2).text =
                    (getString(R.string.text_response) + " TF2")
            }
        }

        findViewById<CheckBox>(R.id.checkBox).setOnClickListener {
            if (findViewById<CheckBox>(R.id.checkBox).isChecked){
                findViewById <TextView> (R.id.textView2).text = (getString(R.string.text_opinion_response))
            } else {
                findViewById <TextView> (R.id.textView2).text = (getString(R.string.text_opinion_response_negative))
            }
        }
    }
}