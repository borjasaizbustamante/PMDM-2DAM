package com.example.geo

import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var googleMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Find the map fragment and request the GoogleMap asynchronously
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this) // onMapReady() will be called when map is ready

        val searchBtn: ImageButton = findViewById(R.id.searchbtn)

        // Load and start rotation animation for the search button (can indicate "loading" state)
        val rotate = AnimationUtils.loadAnimation(searchBtn.context, R.anim.rotate)
        searchBtn.startAnimation(rotate)

        // search button click
        searchBtn.setOnClickListener {
            val latText = findViewById<EditText>(R.id.longitudinput).text.toString()
            val lonText = findViewById<EditText>(R.id.latitudinput).text.toString()

            // Only proceed if both fields are filled
            if (latText.isNotEmpty() && lonText.isNotEmpty()) {
                val lon = latText.toDoubleOrNull() // Convert input to Double safely
                val lat = lonText.toDoubleOrNull()

                // Only proceed if the conversion was successful
                if (lat != null && lon != null) {
                    val location = LatLng(lat, lon) // Create LatLng object for the coordinates

                    googleMap.clear() // Remove any previous markers
                    googleMap.addMarker(MarkerOptions().position(location).title("Marker")) // Add new marker
                    googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 17f)) // Zoom to the location
                }
            }
        }
    }

    // Called when the GoogleMap is ready to be used
    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Set a default location to show initially (Elorrieta Erreka Mari)
        val defaultLocation = LatLng(43.28366, -2.964798)
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 15f)) // Move camera to default location
    }
}
