package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.simplecalculator.operations.Operations;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private boolean operationDone = false;

    private TextView textError = null;
    private TextView textView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        textError = (TextView) findViewById(R.id.textError);
        textError.setVisibility(View.GONE);
        textView = (TextView) findViewById(R.id.textView);

        Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(this);
        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(this);
        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(this);
        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(this);
        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(this);
        Button button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(this);
        Button button7 = (Button) findViewById(R.id.button7);
        button7.setOnClickListener(this);
        Button button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(this);
        Button button9 = (Button) findViewById(R.id.button9);
        button9.setOnClickListener(this);
        Button button0 = (Button) findViewById(R.id.button0);
        button0.setOnClickListener(this);

        Button buttonAdd = (Button) findViewById(R.id.buttonAdd);
        buttonAdd.setOnClickListener(this);
        Button buttonSubstract = (Button) findViewById(R.id.buttonSubstract);
        buttonSubstract.setOnClickListener(this);
        Button buttonResult = (Button) findViewById(R.id.buttonResult);
        buttonResult.setOnClickListener(this);
    }

    @Override
    public void onClick (View v){
        try{
            if (operationDone) {
                textView.setText( "" );
                operationDone = false;
            }
            doOnClick (v);
        } catch (Exception e){
            textError.setVisibility(View.VISIBLE);
            textView.setText("");
        }
    }

    public void doOnClick (View v) throws Exception {
        textError.setVisibility(View.GONE);

        // Las cosas no se hacen asi... pero por el momento, vale
        switch (v.getId()){
            case R.id.button1:          textView.setText(textView.getText().toString() + "1"); break;
            case R.id.button2:          textView.setText(textView.getText().toString() + "2"); break;
            case R.id.button3:          textView.setText(textView.getText().toString() + "3"); break;
            case R.id.button4:          textView.setText(textView.getText().toString() + "4"); break;
            case R.id.button5:          textView.setText(textView.getText().toString() + "5"); break;
            case R.id.button6:          textView.setText(textView.getText().toString() + "6"); break;
            case R.id.button7:          textView.setText(textView.getText().toString() + "7"); break;
            case R.id.button8:          textView.setText(textView.getText().toString() + "8"); break;
            case R.id.button9:          textView.setText(textView.getText().toString() + "9"); break;
            case R.id.button0:          textView.setText(textView.getText().toString() + "0"); break;
            case R.id.buttonAdd:        textView.setText(textView.getText().toString() + " + "); break;
            case R.id.buttonSubstract:  textView.setText(textView.getText().toString() + " - "); break;
            case R.id.buttonResult:     textView.setText(Operations.doOperation(textView.getText().toString()));
                                        operationDone = true;
                                        break;
        }
    }
}