package com.example.intentexplicito;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class ProvinciaActivity extends AppCompatActivity {

    private String choice = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_provincia );

        RadioGroup radioGroup = (RadioGroup) findViewById (R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radioButtonVizcaya: choice = getString(R.string.vizcaya); break;
                    case R.id.radioButtonGuipuzcoa: choice = getString(R.string.guipuzcoa); break;
                    case R.id.radioButtonAlava: choice = getString(R.string.alaba); break;
                    case R.id.radioButtonNavarra: choice = getString(R.string.navarra); break;
                }
            }
        });

        Button button= (Button) findViewById(R.id.button);
        button.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Vamos a volver al Main Activity.
                Intent intent = new Intent ();

                // ¿Ha seleccionado un radioButton?
                if (choice != null){
                    // Le decimos que ha ido BIEN
                    setResult(RESULT_OK, intent);
                    // Le pasamos la selección del RadioButton con el nombre de "Provincia"
                    intent.putExtra("PROVINCIA", choice);
                } else {
                    // Le decimos que ha ido MAL
                    setResult(RESULT_CANCELED, intent);
                }
                finish();
            }
        } );
    }
}