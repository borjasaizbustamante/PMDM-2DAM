package com.example.intentexplicito;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Actividad principal. Esta Activity está relacionada con activity_main.xml
 */
public class MainActivity extends AppCompatActivity {

    // Para identificar todos los Activity y así saber
    // distinguirlos en el onActivityResult().
    // En esta App, sólo hay uno...
    public static final int PROVINCIA_ACTIVITY = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        // Bu
        Button button= (Button) findViewById(R.id.button);
        button.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // El Intent al otro Activity. No le pasamos nada
                Intent intent = new Intent (MainActivity.this, ProvinciaActivity.class);
                startActivityForResult(intent, PROVINCIA_ACTIVITY);
            }
        } );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult( requestCode, resultCode, data );
        TextView textView = (TextView) findViewById( R.id.responseTxt );

        // ¿De qué Activity volvemos? De PROVINCIA_ACTIVITY
        // Si hubiese más, se diferenciarían aquí
        if (requestCode == PROVINCIA_ACTIVITY) {
            // Si ha resultado
            if (resultCode == RESULT_OK) {
                // El dato "PROVINCIA" nos lo han pasado como String. Lo mostramos
                textView.setText( data.getStringExtra( "PROVINCIA" ) );
            } else {
                // Tratamiento del error
                Toast.makeText(getApplicationContext(), getString (R.string.error_txt ), Toast.LENGTH_SHORT).show();
                textView.setText("");
            }
        }
    }
}