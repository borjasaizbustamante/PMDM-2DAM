package es.pruebas.simplecalculatorkotlin

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import es.pruebas.simplecalculatorkotlin.operations.doOperation

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private var operationDone : Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById <TextView>(R.id.textError).visibility = View.GONE

        findViewById<Button>(R.id.button1).setOnClickListener(this)
        findViewById<Button>(R.id.button2).setOnClickListener(this)
        findViewById<Button>(R.id.button3).setOnClickListener(this)
        findViewById<Button>(R.id.button4).setOnClickListener(this)
        findViewById<Button>(R.id.button5).setOnClickListener(this)
        findViewById<Button>(R.id.button6).setOnClickListener(this)
        findViewById<Button>(R.id.button7).setOnClickListener(this)
        findViewById<Button>(R.id.button8).setOnClickListener(this)
        findViewById<Button>(R.id.button9).setOnClickListener(this)
        findViewById<Button>(R.id.button0).setOnClickListener(this)
        findViewById<Button>(R.id.buttonAdd).setOnClickListener(this)
        findViewById<Button>(R.id.buttonSubstract).setOnClickListener(this)
        findViewById<Button>(R.id.buttonResult).setOnClickListener(this)
    }

    @SuppressLint("SetTextI18n")
    override fun onClick(view: View?) {
        val textView : TextView = findViewById(R.id.textView)
        findViewById <TextView>(R.id.textError).visibility = View.GONE

        if (operationDone) {
            textView.text = ""
            operationDone = false
        } else {
            when (view?.id) {
                R.id.button1 -> textView.text = textView.text.toString() + getString(R.string.txt_one)
                R.id.button2 -> textView.text = textView.text.toString() + getString(R.string.txt_two)
                R.id.button3 -> textView.text = textView.text.toString() + getString(R.string.txt_three)
                R.id.button4 -> textView.text = textView.text.toString() + getString(R.string.txt_four)
                R.id.button5 -> textView.text = textView.text.toString() + getString(R.string.txt_five)
                R.id.button6 -> textView.text = textView.text.toString() + getString(R.string.txt_six)
                R.id.button7 -> textView.text = textView.text.toString() + getString(R.string.txt_seven)
                R.id.button8 -> textView.text = textView.text.toString() + getString(R.string.txt_eight)
                R.id.button9 -> textView.text = textView.text.toString() + getString(R.string.txt_nine)
                R.id.button0 -> textView.text = textView.text.toString() + getString(R.string.txt_zero)
                R.id.buttonAdd -> textView.text = textView.text.toString() + getString(R.string.txt_add)
                R.id.buttonSubstract -> textView.text =
                    textView.text.toString() + getString(R.string.txt_substract)
                R.id.buttonResult -> {
                    try {
                        textView.text = doOperation(textView.text.toString())
                        operationDone = true
                    } catch (e: Exception) {
                        findViewById<TextView>(R.id.textError).visibility = View.VISIBLE
                        textView.text = ""
                    }
                }
            }
        }
    }
}