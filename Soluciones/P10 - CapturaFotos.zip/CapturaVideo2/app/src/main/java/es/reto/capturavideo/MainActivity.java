package es.reto.capturavideo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;
import android.widget.VideoView;

/**
 * Cortesía de - Luis Carlos Salvatierra
 */
public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_VIDEO_CAPTURE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Botón de grabación
        (findViewById(R.id.buttonCamera)).setOnClickListener(V -> {

            // Lanzamos el Intent. Queremos que responda 'alguien'
            // que sea capaz de realizar la acción ACTION_VIDEO_CAPTURE
            Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

            // Si existe alguien capaz de hacerlo...
            if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
                // Le hacemos un Intent
                startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
            } else {
                // Si no lo hay, avisamos
                Toast.makeText(getApplicationContext(), getText(R.string.errorNoCamera), Toast.LENGTH_LONG).show();
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {

        // Respuesta del recurso que ha aceptado la acción
        super.onActivityResult(requestCode, resultCode, intent);

        // Tenemos respuesta correcta...
        if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK) {

            // Sacamos el vídeo y lo mostramos
            Uri videoUri = intent.getData();
            ((VideoView) findViewById(R.id.videoView)).setVideoURI(videoUri);
            ((VideoView) findViewById(R.id.videoView)).start();
        } else {
            // Algo ha ido mal...
            Toast.makeText(getApplicationContext(), getText(R.string.errorCamera), Toast.LENGTH_LONG).show();
        }
    }
}