package com.example.intentsimplicitos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // The Implicit Intent we want to make
    Intent intent = null;

    // The chooser
    Intent chooser = null;

    Button buttonWeb = null;
    Button buttonMap = null;
    Button buttonEmail = null;

    EditText webText = null;
    EditText latText = null;
    EditText longText = null;
    EditText mailText = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        buttonWeb = (Button) findViewById( R.id.buttonWeb );
        buttonMap = (Button) findViewById( R.id.buttonMap );
        buttonEmail = (Button) findViewById( R.id.buttonEmail );

        webText = (EditText) findViewById( R.id.webText );
        latText = (EditText) findViewById( R.id.latText );
        longText = (EditText) findViewById( R.id.longText );
        mailText = (EditText) findViewById( R.id.mailText );

        // URL button
        buttonWeb.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webActionOnClick ();
            }
        } );

        // Map button
        buttonMap.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapActionOnClick ();
            }
        } );

        // Mail button
        buttonEmail.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailActionOnClick ();
            }
        } );
    }

    private void webActionOnClick () {
        if (!webText.getText().toString().isEmpty()) {
            intent = new Intent();
            intent.setAction( Intent.ACTION_VIEW );
            String URL = webText.getText().toString(); // Do not forget the https:
            URL = URL.contains("http://")? URL :  "https://" + URL;
            intent.setData( Uri.parse( URL ) );

            // We can startActivity from Chooser or from Intent.
            // If from Chooser, we can "choose" wich App to open.
            // If from Intent, the default App will be started
            chooser = intent.createChooser(intent, getText( R.string.txt_intent_web ));

            if ((chooser.resolveActivity(getPackageManager())) != null) {
                startActivity(chooser);
                Toast.makeText(this, getText( R.string.txt_ok ), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, getText( R.string.txt_error_2 ), Toast.LENGTH_LONG).show();
            }

        } else {
            Toast.makeText(this, getText( R.string.txt_error_1 ), Toast.LENGTH_LONG).show();
        }
    }

    private void mapActionOnClick () {
        if ((!latText.getText().toString().isEmpty()) ||
                (!longText.getText().toString().isEmpty())){
            intent = new Intent();
            intent.setAction( Intent.ACTION_VIEW );

            // Preparing the coordinates...
            intent.setData( Uri.parse("geo:" + latText.getText().toString() + ", " + longText.getText().toString()) );
            chooser = intent.createChooser(intent, getText( R.string.txt_intent_map ));
            if ((chooser.resolveActivity(getPackageManager())) != null) {
                startActivity(chooser);
                Toast.makeText(this, getText( R.string.txt_ok ), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, getText( R.string.txt_error_4 ), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, getText( R.string.txt_error_3 ), Toast.LENGTH_LONG).show();
        }
    }

    private void emailActionOnClick () {
        if (!mailText.getText().toString().isEmpty()) {
            intent = new Intent();
            intent.setAction( Intent.ACTION_SEND );

            // Preparing the mail...
            intent.setData( Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_EMAIL, new String [] {mailText.getText().toString()});
            intent.putExtra(Intent.EXTRA_SUBJECT, getText( R.string.txt_mail_Title ));
            intent.putExtra(Intent.EXTRA_TEXT, getText( R.string.txt_mail_content ));
            intent.setType( getText( R.string.mail_MIME).toString());

            chooser = intent.createChooser(intent, getText( R.string.txt_intent_mail ));
            if ((chooser.resolveActivity(getPackageManager())) != null) {
                startActivity(chooser);
                Toast.makeText(this, getText( R.string.txt_ok ), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, getText( R.string.txt_error_6 ), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, getText( R.string.txt_error_5 ), Toast.LENGTH_LONG).show();
        }
    }
}