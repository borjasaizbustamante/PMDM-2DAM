package com.example.thebestestvideogame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, CheckBox.OnCheckedChangeListener{

    private TextView textView2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        textView2 = (TextView) findViewById (R.id.textView2);

        RadioGroup radioGroup = (RadioGroup) findViewById (R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(this);

        CheckBox checkBox = (CheckBox) findViewById (R.id.checkBox);
        checkBox.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId){
            case R.id.radioButtonFallout: textView2.setText (getString(R.string.text_response) + " Fallout"); break;
            case R.id.radioButtonLol: textView2.setText (getString(R.string.text_response) + " Lol"); break;
            case R.id.radioButtonFortnite: textView2.setText (getString(R.string.text_response) + " Fortnite"); break;
            case R.id.radioButtonTF2: textView2.setText (getString(R.string.text_response) + " TF2"); break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked){
            textView2.setText (getString(R.string.text_opinion_response));
        } else {
            textView2.setText (getString(R.string.text_opinion_response_negative));
        }
    }
}