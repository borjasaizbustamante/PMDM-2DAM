package es.pruebas.buttonandtextviewkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

// Los : equivalen al extends de Java. El () es para decirle que el constructor MainActivity
// hace un super() al constructor vacío de AppCompatActivity. Kotlin en muchos casos va de
// ahorrarse líneas de código de cosas que en Java son redundantes. Puedes llamar a
// constructores sobrecargados, etc.
class MainActivity : AppCompatActivity() {

    // En kotlin no puede ser que una variable valga null.
    // Para permitir que pueda ser null, se le tiene que poner ?
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Las variables mejor dentro del metodo
        // Se define una variable usando val o var.
        // val -> solo lectura
        // val -> puedes alterar su valor
        val textView : TextView = findViewById(R.id.textView)
        val button : Button = findViewById(R.id.button)

        // Se le asigna el evento directamente (para entendernos)
        button.setOnClickListener {

            // En Kotlin se asume que cuando pones un atributo a una clase,
            // si quieres hacerlo accesible, le vas a poner un get/set.
            // El textView.text es en realidad un textView.getText()
            val textViewText = textView.text.toString()

            // Kotlin no necesita que le digas el tipo de dato. Es capaz de
            // adivinarlo solo. Por ejemplo, aquí ya sabe que textOk es un String
            val textOk = getString(R.string.text_click)
            val textHello = getString(R.string.text_hello_world)

            // Forma resumida de hacer un if-else. Y un equals entre Strings
            textView.text = if (textViewText == textOk) textHello else textOk
        }
    }
}