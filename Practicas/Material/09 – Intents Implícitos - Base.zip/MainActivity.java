package com.example.intentsimplicitos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // The Implicit Intent we want to make
    Intent intent = null;

    // The chooser
    Intent chooser = null;

    Button buttonWeb = null;
    Button buttonMap = null;
    Button buttonEmail = null;

    EditText webText = null;
    EditText latText = null;
    EditText longText = null;
    EditText mailText = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        buttonWeb = (Button) findViewById( R.id.buttonWeb );
        buttonMap = (Button) findViewById( R.id.buttonMap );
        buttonEmail = (Button) findViewById( R.id.buttonEmail );

        webText = (EditText) findViewById( R.id.webText );
        latText = (EditText) findViewById( R.id.latText );
        longText = (EditText) findViewById( R.id.longText );
        mailText = (EditText) findViewById( R.id.mailText );

        // URL button
        buttonWeb.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webActionOnClick ();
            }
        } );

        // Map button
        buttonMap.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapActionOnClick ();
            }
        } );

        // Mail button
        buttonEmail.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailActionOnClick ();
            }
        } );
    }

    private void webActionOnClick () {
        
    }

    private void mapActionOnClick () {
        
    }

    private void emailActionOnClick () {
       
    }
}