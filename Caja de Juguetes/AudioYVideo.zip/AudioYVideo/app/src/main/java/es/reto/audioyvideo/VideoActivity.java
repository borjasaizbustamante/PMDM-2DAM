package es.reto.audioyvideo;

import androidx.appcompat.app.AppCompatActivity;

import android.view.MotionEvent;
import android.widget.MediaController;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import android.widget.VideoView;

public class VideoActivity extends AppCompatActivity {

    private MediaController mediaController;
    private VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_video );

        videoView = (VideoView) findViewById(R.id.idVideoView);
        mediaController = new MediaController(this);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);
        videoView.setVideoURI(
                Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.bunny));

        videoView.setOnPreparedListener( mp -> {
            Toast.makeText(getBaseContext(), getString( R.string.video_ready ), Toast.LENGTH_LONG).show();
            mediaController.show(20000);
            videoView.start();
        } );

        videoView.setOnCompletionListener( mp -> {
            Toast.makeText(getBaseContext(),getString( R.string.video_end ),Toast.LENGTH_LONG).show();
            mediaController.show(20000);
        } );
    }

    @Override
    // Cuando el usuario toca la pantalla, mostrar el reproductor
    public boolean onTouchEvent(MotionEvent event) {
        mediaController.show();
        return false;
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        videoView.stopPlayback();
    }
}