package es.pruebas.firebasetextrecognition;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import com.google.mlkit.vision.common.InputImage;
import android.graphics.Point;
import android.graphics.Rect;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

/**
 * A text recognition example. Some changes have been made to the AndroidManifest and
 * to the build.gradle. This code is mostly a big sample code filled with unused or
 * redundant parts. Most unused variables (I.E. blockCornerPoints) are set for learning
 * purposes only.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        // The activity result for the Intent that calls for the camera
        ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                activityResult -> {
                    if ((activityResult.getResultCode() == RESULT_OK) && (activityResult.getData() != null)) {

                        // Get the image and displays it
                        // Note this method is called when the photo is taken!
                        Bundle bundle = activityResult.getData().getExtras();
                        Bitmap bitmap = (Bitmap) bundle.get( "data" );
                        ((ImageView) findViewById( R.id.imageView )).setImageBitmap( bitmap );

                        // The image with text
                        InputImage image = InputImage.fromBitmap( bitmap, 0 );

                        // The text recognizer
                        TextRecognizer textRecognizer = TextRecognition.getClient( TextRecognizerOptions.DEFAULT_OPTIONS );

                        // Detects latin-based characters from the supplied image.
                        textRecognizer.process( image ).addOnSuccessListener( visionText -> {

                            // All the text in the image. We show it via text view
                            String allTextOnImage = visionText.getText();
                            ((TextView) findViewById( R.id.extractedTextView )).setText( allTextOnImage );

                            // Now... little by little...
                            // We have several text blocks. Let's loop them all...
                            for (Text.TextBlock block : visionText.getTextBlocks()) {

                                // The text in the text block and several other attributes
                                // String blockText = block.getText();
                                // Point[] blockCornerPoints = block.getCornerPoints();
                                // Rect blockBoundingBox = block.getBoundingBox();

                                // A text block has many text lines. Let's loop again...
                                for (Text.Line line : block.getLines()) {

                                    // The text in the text line and several other attributes
                                    // String lineText = line.getText();
                                    // Point[] lineCornerPoints = line.getCornerPoints();
                                    // Rect lineBoundingBox = line.getBoundingBox();

                                    // A text line has many elements (words). Let's loop them all...
                                    for (Text.Element element : line.getElements()) {

                                        // String elementText = element.getText();
                                        // Point[] elementCornerPoints = element.getCornerPoints();
                                        // Rect elementBoundingPoints = element.getBoundingBox();
                                    }
                                }
                            }
                        } ).addOnFailureListener( e -> Toast.makeText( getApplicationContext(), getString( R.string.text_recong_err ), Toast.LENGTH_LONG ).show() );
                    }
                } );
        // The button
        (findViewById( R.id.buttonCamera )).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent takePhotoIntent = new Intent( MediaStore.ACTION_IMAGE_CAPTURE );

                // Is there a camera? If yes, then intent!
                if (takePhotoIntent.resolveActivity( getPackageManager() ) != null) {
                    activityResultLauncher.launch(takePhotoIntent);
                } else {
                    Toast.makeText( getApplicationContext(), getText( R.string.no_camera_error ), Toast.LENGTH_LONG ).show();
                }
            }
        } );
    }
}