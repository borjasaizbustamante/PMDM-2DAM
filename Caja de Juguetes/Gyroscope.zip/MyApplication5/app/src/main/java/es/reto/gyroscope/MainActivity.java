package es.reto.gyroscope;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

/**
 * How can we make use of the phone gyroscope? Well... I copied this
 * from the Internet and played a bit with the code. It only works
 * on phones, not in emulations... Have fun!
 */
public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager = null;
    private SensorEventListener sensorEventListener = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        // We want to use the gyroscope
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        // Put the screen sideways
        setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    // Whenever the Activity stops, we unregister the sensor event
    @Override
    public void onStop() {
        super.onStop();
        sensorManager.unregisterListener(sensorEventListener);
    }

    // ... and when the Activity resumes, whe registers it again
    // Do not panic with the inner class!! We are just calling to
    // registerListener(), which needs 3 arguments. The first one is
    // a SensorEventListener dynamically created as a inner class. The
    // second is the default Gyroscope sensor, and the las one is just
    // the delay.
    //
    // I got bored, Ok?
    @Override
    public void onResume() {
        super.onResume();
        sensorManager.registerListener(sensorEventListener = new SensorEventListener() {
            public void onAccuracyChanged(Sensor sensor, int acc) {
                // Nothing to see here!
            }

            // Did somebody moved the phone?
            public void onSensorChanged(SensorEvent event) {
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];

                ((TextView)findViewById(R.id.textX)).setText("X : " + (int) x + " rad/s");
                ((TextView)findViewById(R.id.textY)).setText("Y : " + (int) y + " rad/s");
                ((TextView)findViewById(R.id.textZ)).setText("Z : " + (int) z + " rad/s");
            }
        }, sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
                SensorManager.SENSOR_DELAY_NORMAL);
    }
}