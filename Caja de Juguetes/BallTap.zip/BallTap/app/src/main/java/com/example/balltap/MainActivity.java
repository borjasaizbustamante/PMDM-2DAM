package com.example.balltap;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        if (null != getSupportActionBar())
            getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        ImageView[] imageList = new ImageView[]{
                findViewById(R.id.image_view1),
                findViewById(R.id.image_view2),
                findViewById(R.id.image_view3),
                findViewById(R.id.image_view4),
                findViewById(R.id.image_view5),
                findViewById(R.id.image_view6),
                findViewById(R.id.image_view7),
                findViewById(R.id.image_view8),
                findViewById(R.id.image_view9)
        };

        View.OnClickListener genericOnCLickListener = v -> {
            score = score + 1;
            ((TextView) findViewById(R.id.score)).setText(getResources().getString(R.string.score, score));
        };

        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                for(ImageView imageView:imageList){
                    imageView.setImageResource(R.drawable.pokeball);
                    imageView.setOnClickListener(genericOnCLickListener); // Add the generic behaviour
                    final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(() -> imageView.setImageResource(R.drawable.pokeball),900);
                    imageView.setVisibility(View.INVISIBLE);
                }

                // Show a random image
                imageList[new Random().nextInt(9)].setVisibility(View.VISIBLE);
                handler.postDelayed(this,600);
            }
        };
        handler.post(runnable);

        // The timer
        new CountDownTimer(10000,1000) {

            // Each tick of the clock
            @Override
            public void onTick(long l) {
                ((TextView)findViewById(R.id.time)).setText(getResources().getString(R.string.time_x, l/1000));
            }

            // Time's up!
            @Override
            public void onFinish() {
                ((TextView)findViewById(R.id.time)).setText(getResources().getString(R.string.time_over));
                handler.removeCallbacks(runnable);

                // hide all images
                for (ImageView image:imageList) {
                    image.setVisibility(View.INVISIBLE);
                }

                // dialog box to ask user's input
                AlertDialog.Builder alert=new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Try Again!");
                alert.setMessage("Do you want to restart?");

                // if user wants to restart game
                alert.setPositiveButton("Yes", (dialogInterface, i) -> {
                    Intent intent=getIntent();
                    finish();
                    startActivity(intent);
                });

                // if not
                alert.setNegativeButton("No", (dialogInterface, i) -> Toast.makeText(MainActivity.this, "Game Over!!!", Toast.LENGTH_SHORT).show());
                alert.show();
            }
        }.start();
    }
}