package es.reto.loadingscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/**
 * Well... now you can start coding your own App!!
 */
public class SecondaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_secondary );
    }
}