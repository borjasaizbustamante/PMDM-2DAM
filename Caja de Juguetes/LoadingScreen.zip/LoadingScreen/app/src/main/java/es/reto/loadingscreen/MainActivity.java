package es.reto.loadingscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import com.bumptech.glide.Glide;

/**
 * This is the Activity which control the Loading Screen of the App.
 * Please, notice we are using a .gif instead of a regular animation,
 * so we are cheating!
 */
public class MainActivity extends AppCompatActivity {

    // The Progress Bar
    private ProgressBar progressBar = null;

    /**
     * AsyncTask<Params, Progress, Result>
     *
     * This is an Internal Class we need to handle the Progress Bar. AsyncTask
     * is how Android wants you to manage Threads. It's a VERY bad idea to
     * manage Threads your own like in regular Java.
     */
    class MainActivityAsyncTask extends AsyncTask<Integer, Integer, String> {

        /**
         * Method called before task execution on UI thread. Disables the user
         * interaction with the screen. Blocks user touch events, so he cannot
         * do anything wrong.
         */
        @Override
        protected void onPreExecute() {
            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            );
        }

        /**
         * Method called just after execution of onPreExecute() in background thread.
         *
         * @param params The params
         * @return Empty string
         */
        @Override
        protected String doInBackground(Integer... params) {

            // You are doing a loading screen because your App have to do something
            // important before the user can play with it, right? Put that code here!
            //
            // The following code is an example...

            // The Progress Barr will 'progress' after a fixed amount of time.
            // Obviously, this is try - catch shenanigan is made only for learning
            // purposes... Change it for your code!

            try {
                Thread.sleep(1000);
                progressBar.setProgress(25);
            } catch (InterruptedException e) {
                // Nothing...
            }
            try {
                Thread.sleep(2000);
                progressBar.setProgress(50);
            } catch (InterruptedException e) {
                // Nothing...
            }
            try {
                Thread.sleep(3000);
                progressBar.setProgress(75);
            } catch (InterruptedException e) {
                // Nothing...
            }
            try {
                Thread.sleep(2000);
                progressBar.setProgress(100);
            } catch (InterruptedException e) {
                // Nothing...
            }

            return "";
        }

        /**
         * Method is called on UI thread after calling publishProgress(Progress...) within the
         * doInBackground(Params...) for any status update like progress bar.
         *
         * @param values Teh values
         */
        @Override
        protected void onProgressUpdate(Integer... values) {
            progressBar.setProgress(values[0]);
        }

        /**
         * Method is called on UI thread just after completion of doInBackground(Params...) and the
         * result is passed to onPostExecute(Result). Enables the user interaction with the screen.
         * Unblocks user touch events.
         *
         * We also make the textView visible...
         *
         * @param result the result
         */
        @Override
        protected void onPostExecute(String result) {
            //progressBar.setVisibility( View.GONE);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

            (findViewById(R.id.textView)).setVisibility( View.VISIBLE );
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        (findViewById(R.id.constraintLayout)).setBackgroundColor( Color.parseColor("#000000"));

        // Event for the "Touch the screen to go..."
        findViewById(R.id.constraintLayout).setOnTouchListener(
                (v, m) -> {
                    Intent intent = new Intent( MainActivity.this, SecondaryActivity.class );
                    startActivity(intent);
                    return true;
                }
        );

        // Vault boy gif walking. Android does NOT like the .GIF, so we are going
        // to use second-party code. Go to the build.gradle file to look how to
        // set the Glide dependency. Doing a simple "import com.bumptech.glide.Glide;"
        // will NOT WORK
        ImageView imageView = findViewById(R.id.vaultboyGif);
        Glide.with(this).load(R.raw.vaultboywalking).into(imageView);

        // The progress bar
        progressBar = findViewById( R.id.datBaseLoadingBar);
        progressBar.setMax(100);
        progressBar.setProgress(0);

        // Everything is set, let's put it all to work!!
        new MainActivityAsyncTask().execute();
    }
}