package com.example.spinwheelkotlin

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    companion object {
        private const val INITIAL_ROTATION_SPEED = -50f
        private const val DECELERATION_FACTOR = 0.98f
    }

    private lateinit var spinButton: Button
    private lateinit var wheelImage: ImageView
    private var spinTimer: CountDownTimer? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        spinButton = findViewById(R.id.spinButton)
        wheelImage = findViewById(R.id.wheelImage)

        spinButton.setOnClickListener {
            spinButton.isEnabled = false

            val duration = ((Random.nextInt(20) + 10) * 30 * 20).toLong()

            spinTimer = object : CountDownTimer(duration, 16) { // ~60 FPS
                var rotationSpeed = INITIAL_ROTATION_SPEED

                override fun onTick(millisUntilFinished: Long) {
                    var rotation = wheelImage.rotation + rotationSpeed
                    if (rotation <= -360f) rotation = 0f
                    wheelImage.rotation = rotation

                    // Gradually reduce rotation speed
                    rotationSpeed *= DECELERATION_FACTOR
                }

                override fun onFinish() {
                    spinButton.isEnabled = true
                    val finalRotation = wheelImage.rotation.toInt()
                    val segment = abs(ceil(finalRotation / 30.0 - 1)).toInt()
                    Toast.makeText(this@MainActivity, "$segment", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Cancel timer if activity is destroyed to avoid NPE
        spinTimer?.cancel()
    }
}