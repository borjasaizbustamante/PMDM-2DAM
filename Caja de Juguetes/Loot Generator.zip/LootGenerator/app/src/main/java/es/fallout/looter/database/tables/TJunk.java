package es.fallout.looter.database.tables;

/**
 * TJunk table
 */
public class TJunk extends TGenericTwoColumnDrop{

    public TJunk(){}

    public TJunk(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
