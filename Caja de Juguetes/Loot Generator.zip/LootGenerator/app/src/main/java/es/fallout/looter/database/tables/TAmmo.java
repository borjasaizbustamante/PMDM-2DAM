package es.fallout.looter.database.tables;

/**
 * Ammo table
 */
public class TAmmo  extends TGenericTwoColumnDrop{

    public TAmmo (){}

    public TAmmo (TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
