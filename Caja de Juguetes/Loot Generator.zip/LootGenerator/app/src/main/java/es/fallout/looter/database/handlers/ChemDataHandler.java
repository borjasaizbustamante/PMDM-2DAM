package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TChem;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Chem
 */
public class ChemDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TChem> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public ChemDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( GenericIdDropDataHandler.class.getName(), "populate " + TABLE_NAME_CHEM );
        Log.i ( AmmoDataHandler.class.getName(), "populate " + TABLE_NAME_CHEM );
        TChem tChem;
        for (int i = 2; i <= 40; i++){
            tChem = new TChem ();
            tChem.setId(i);
            tChem.setDrop(context.getString( Utils.getStringId( TABLE_NAME_CHEM + "_C2_F" + i)));
            insert (tChem);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop ( TABLE_NAME_CHEM );
    }

    /**
     * Selects * from table
     *
     * @return List<TAmmo>
     */
    public List<TChem> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_CHEM );
        return Utils.downcast (list, TChem::new);
    }

    /**
     * Insert into table
     *
     * @param tChem The row
     */
    public void insert(TChem tChem) {
        insert (tChem, TABLE_NAME_CHEM, COLUMN_ID, COLUMN_CHEM);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TArmor
     */
    public TChem selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_CHEM, COLUMN_ID);
        return new TChem(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_CHEM, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tChem The row
     * @return boolean
     */
    public boolean update(TChem tChem) {
        return update (tChem, TABLE_NAME_CHEM, COLUMN_ID, COLUMN_CHEM);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists( TABLE_NAME_CHEM );
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty( TABLE_NAME_CHEM );
    }
}
