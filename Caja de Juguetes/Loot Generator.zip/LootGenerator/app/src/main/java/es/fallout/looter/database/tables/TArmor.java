package es.fallout.looter.database.tables;

/**
 * Armor table
 */
public class TArmor extends TGenericTwoColumnDrop{

    public TArmor (){}

    public TArmor (TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
