package es.fallout.looter.database.tables;

/**
 * Oddities table
 */
public class TOddities extends TGenericTwoColumnDrop{

    public TOddities(){}

    public TOddities(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
