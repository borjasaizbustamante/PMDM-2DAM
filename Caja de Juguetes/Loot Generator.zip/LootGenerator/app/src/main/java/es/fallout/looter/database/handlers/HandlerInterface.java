package es.fallout.looter.database.handlers;

import java.util.List;

/**
 * Interface for Data Handlers
 * 
 * @param <T>
 */
public interface HandlerInterface<T> {

    void populate ();

    void drop();

    List<T> selectAll();

    void insert(T t);

    T selectById(int id);

    int deleteById(int id);

    boolean update(T t);

    boolean ifTableExists();

    boolean isEmpty();
}
