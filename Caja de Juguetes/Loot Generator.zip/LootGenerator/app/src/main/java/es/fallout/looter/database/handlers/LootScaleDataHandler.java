package es.fallout.looter.database.handlers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import es.fallout.looter.R;
import es.fallout.looter.database.tables.TLootScale;

/**
 * Loot Scale Table
 */
public class LootScaleDataHandler extends DataHandler implements HandlerInterface <TLootScale>{

    /**
     * Constructor
     *
     * @param context The context
     */
    public LootScaleDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    public void populate (){
        Log.i ( LootScaleDataHandler.class.getName(), "populate " + TABLE_NAME_LOOT_SCALE );
        TLootScale tLootScale;

        tLootScale = new TLootScale();
        tLootScale.setId(1);
        tLootScale.setScale(context.getString( R.string.TScaleExampleTimeDataHandler_C1_F1));
        tLootScale.setExample(context.getString( R.string.TScaleExampleTimeDataHandler_C2_F1));
        tLootScale.setTime(context.getString( R.string.TScaleExampleTimeDataHandler_C3_F1));
        insert( tLootScale );

        tLootScale = new TLootScale();
        tLootScale.setId(2);
        tLootScale.setScale(context.getString( R.string.TScaleExampleTimeDataHandler_C1_F2));
        tLootScale.setExample(context.getString( R.string.TScaleExampleTimeDataHandler_C2_F2));
        tLootScale.setTime(context.getString( R.string.TScaleExampleTimeDataHandler_C3_F2));
        insert( tLootScale );

        tLootScale = new TLootScale();
        tLootScale.setId(3);
        tLootScale.setScale(context.getString( R.string.TScaleExampleTimeDataHandler_C1_F3));
        tLootScale.setExample(context.getString( R.string.TScaleExampleTimeDataHandler_C2_F3));
        tLootScale.setTime(context.getString( R.string.TScaleExampleTimeDataHandler_C3_F3));
        insert( tLootScale );

        tLootScale = new TLootScale();
        tLootScale.setId(4);
        tLootScale.setScale(context.getString( R.string.TScaleExampleTimeDataHandler_C1_F4));
        tLootScale.setExample(context.getString( R.string.TScaleExampleTimeDataHandler_C2_F4));
        tLootScale.setTime(context.getString( R.string.TScaleExampleTimeDataHandler_C3_F4));
        insert( tLootScale );
    }

    public void drop (){
        Log.i ( LootScaleDataHandler.class.getName(), "drop " + TABLE_NAME_LOOT_SCALE );
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase ();
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_LOOT_SCALE );
    }

    public List<TLootScale> selectAll () {
        Log.i ( LootScaleDataHandler.class.getName(), "select * from " + TABLE_NAME_LOOT_SCALE );
        List<TLootScale> ret = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_NAME_LOOT_SCALE;
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery(query, null);
        TLootScale tLootScale;
        while (cursor.moveToNext()) {
            tLootScale = new TLootScale();
            tLootScale.setId(cursor.getInt(0));
            tLootScale.setScale(cursor.getString(1));
            tLootScale.setExample(cursor.getString(2));
            tLootScale.setTime(cursor.getString(3));
            ret.add( tLootScale );
        }
        cursor.close();
        sQLiteDatabase.close();
        return ret;
    }

    public void insert (TLootScale tLootScale) {
        Log.i ( LootScaleDataHandler.class.getName(), "insert " + tLootScale.getId() + " into " + TABLE_NAME_LOOT_SCALE );
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, tLootScale.getId());
        values.put(COLUMN_SCALE, tLootScale.getScale());
        values.put(COLUMN_EXAMPLE, tLootScale.getExample());
        values.put(COLUMN_TIME, tLootScale.getTime());

        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.insert( TABLE_NAME_LOOT_SCALE, null, values);
        sQLiteDatabase.close();
    }

    public TLootScale selectById (int id) {
        Log.i ( LootScaleDataHandler.class.getName(), "select * from " + TABLE_NAME_LOOT_SCALE + " where " + id);
        String query = "Select * FROM " + TABLE_NAME_LOOT_SCALE + " WHERE " + COLUMN_ID +
                " = " + "'" + id + "'";
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery(query, null);

        TLootScale tLootScale = new TLootScale();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            tLootScale.setId(cursor.getInt(0));
            tLootScale.setScale(cursor.getString(1));
            tLootScale.setExample(cursor.getString(2));
            tLootScale.setTime(cursor.getString(3));
            cursor.close();
        } else {
            tLootScale = null;
        }
        sQLiteDatabase.close();
        return tLootScale;
    }

    public int deleteById (int id) {
        Log.i ( LootScaleDataHandler.class.getName(), "delete from " + TABLE_NAME_LOOT_SCALE + " where Id = " + id);
        int ret;
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        TLootScale tLootScale = new TLootScale();
        tLootScale.setId(id);
        ret = sQLiteDatabase.delete( TABLE_NAME_LOOT_SCALE, COLUMN_ID + "=?",
                new String[] {
                        String.valueOf( tLootScale.getId())
                });
        sQLiteDatabase.close();
        return ret;
    }

    public boolean update (TLootScale tLootScale) {
        Log.i ( LootScaleDataHandler.class.getName(), "update " + TABLE_NAME_LOOT_SCALE + " set ...");
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(COLUMN_ID, tLootScale.getId());
        args.put(COLUMN_SCALE, tLootScale.getScale());
        args.put(COLUMN_EXAMPLE, tLootScale.getExample());
        args.put(COLUMN_TIME, tLootScale.getTime());
        String whereClause = COLUMN_ID + "=" + tLootScale.getId();
        return sQLiteDatabase.update( TABLE_NAME_LOOT_SCALE, args, whereClause, null) > 0;
    }

    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_LOOT_SCALE);
    }

    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_LOOT_SCALE);
    }
}
