package es.fallout.looter.database.utils;

import android.util.Log;

import java.lang.reflect.Field;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import es.fallout.looter.R;

/**
 * Data Base Utility Class
 */
public class Utils {

    /**
     * Returns the string id in strings.xml by reflexion
     *
     * @param item The item
     * @return the id
     */
    @SuppressWarnings("rawtypes")
    public static int getStringId (String item){
        int id = 0;
        try {
            Class res = R.string.class;
            Field field = res.getField(item);
            id = field.getInt(null);
        }
        catch (Exception e) {
            Log.e ( Utils.class.getName(),"Failure to get string id.", e);
        }
        return id;
    }

    /**
     * Downcast a parent object to his child in a list
     *
     * @param list The list
     * @param func The func
     * @param <E> The E param
     * @param <T> The T param
     * @return <E,T> List<T>
     */
    public static <E,T> List<T> downcast (List<E> list, Function<E, T> func) {
        return list.stream().map(func).collect( Collectors.toList());
    }
 }
