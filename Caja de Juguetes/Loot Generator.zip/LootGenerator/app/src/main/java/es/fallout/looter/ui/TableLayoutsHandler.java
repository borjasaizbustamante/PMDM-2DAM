package es.fallout.looter.ui;

import android.content.Context;
import android.content.res.Resources;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.List;

import es.fallout.looter.R;
import es.fallout.looter.database.handlers.AmmoDataHandler;
import es.fallout.looter.database.handlers.ArmorDataHandler;
import es.fallout.looter.database.handlers.BeveragesDataHandler;
import es.fallout.looter.database.handlers.ChemDataHandler;
import es.fallout.looter.database.handlers.ClothingDataHandler;
import es.fallout.looter.database.handlers.FoodDataHandler;
import es.fallout.looter.database.handlers.JunkDataHandler;
import es.fallout.looter.database.handlers.LootDifficultyDataHandler;
import es.fallout.looter.database.handlers.LootScaleDataHandler;
import es.fallout.looter.database.handlers.MeleeWeaponsDataHandler;
import es.fallout.looter.database.handlers.OdditiesDataHandler;
import es.fallout.looter.database.handlers.RangedWeaponsDataHandler;
import es.fallout.looter.database.handlers.ThrownExplosivesWeaponsDataHandler;
import es.fallout.looter.database.tables.TAmmo;
import es.fallout.looter.database.tables.TArmor;
import es.fallout.looter.database.tables.TBeverages;
import es.fallout.looter.database.tables.TChem;
import es.fallout.looter.database.tables.TClothing;
import es.fallout.looter.database.tables.TFood;
import es.fallout.looter.database.tables.TJunk;
import es.fallout.looter.database.tables.TLootDifficulty;
import es.fallout.looter.database.tables.TLootScale;
import es.fallout.looter.database.tables.TOddities;
import es.fallout.looter.database.tables.TWeaponsMelee;
import es.fallout.looter.database.tables.TWeaponsRanged;
import es.fallout.looter.database.tables.TWeaponsThrownExplosives;

public class TableLayoutsHandler {

    private final Context context;

    public TableLayoutsHandler(Context context){
        this.context = context;
    }

    /**
     * Generates and displays the Loot Difficulty table
     *
     * @param tableLayoutDegreeDifficulty The Table
     * @param lootDifficultyDataHandler The Data Handler
     */
    public void setTableLayoutTDegreeDifficulty(TableLayout tableLayoutDegreeDifficulty, LootDifficultyDataHandler lootDifficultyDataHandler){
        tableLayoutDegreeDifficulty.addView(addRow (
                Resources.getSystem().getString(R.string.TDegreeDifficulty_C1_NAME),
                Resources.getSystem().getString(R.string.TDegreeDifficulty_C2_NAME)
        ));

        List<TLootDifficulty> listOfRowsDegreeDiff = lootDifficultyDataHandler.selectAll();
        for (TLootDifficulty row : listOfRowsDegreeDiff){
            tableLayoutDegreeDifficulty.addView(addRow (row.getDegree(), "" + row.getDifficulty()));
        }
    }

    /**
     * Generates and displays the Loot Scale table
     *
     * @param tableLayoutScaleExampleTime The Table
     * @param lootScaleDataHandler The Data Handler
     */
    public void setTableLayoutTScaleExampleTime (TableLayout tableLayoutScaleExampleTime, LootScaleDataHandler lootScaleDataHandler){
        tableLayoutScaleExampleTime.addView(addRow (
                context.getString(R.string.TScaleExampleTimeDataHandler_C1_NAME),
                context.getString(R.string.TScaleExampleTimeDataHandler_C2_NAME),
                context.getString(R.string.TScaleExampleTimeDataHandler_C3_NAME)
        ));

        // Displays the Table
        List<TLootScale> listOfRows = lootScaleDataHandler.selectAll();
        for (TLootScale row : listOfRows){
            tableLayoutScaleExampleTime.addView(addRow (row.getScale(), row.getExample(), row.getTime()));
        }
    }

    /**
     * Generates and displays the Ammo table
     *
     * @param tableLayoutAmmo The Table
     * @param ammoDataHandler The Data Handler
     */
    public void setTableLayoutTAmmo (TableLayout tableLayoutAmmo, AmmoDataHandler ammoDataHandler){
        tableLayoutAmmo.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TAmmo_C2_NAME)
        ));

        // Displays the Table
        List<TAmmo> listOfRows = (List<TAmmo>) ammoDataHandler.selectAll();
        for (TAmmo row : listOfRows){
            tableLayoutAmmo.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Armor table
     *
     * @param tableLayoutArmor The Table
     * @param armorDataHandler The Data Handler
     */
    public void setTableLayoutTArmor (TableLayout tableLayoutArmor, ArmorDataHandler armorDataHandler){
        tableLayoutArmor.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TArmor_C2_NAME)
        ));

        // Displays the Table
        List<TArmor> listOfRows = (List<TArmor>) armorDataHandler.selectAll();
        for (TArmor row : listOfRows){
            tableLayoutArmor.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Clothing table
     *
     * @param tableLayoutClothing The Table
     * @param clothingDataHandler The Data Handler
     */
    public void setTableLayoutTClothing (TableLayout tableLayoutClothing, ClothingDataHandler clothingDataHandler){
        tableLayoutClothing.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TClothing_C2_NAME)
        ));

        // Displays the Table
        List<TClothing> listOfRows = (List<TClothing>) clothingDataHandler.selectAll();
        for (TClothing row : listOfRows){
            tableLayoutClothing.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Beverage table
     *
     * @param tableLayoutFood The Table
     * @param foodDataHandler The Data Handler
     */
    public void setTableLayoutTFood (TableLayout tableLayoutFood, FoodDataHandler foodDataHandler){
        tableLayoutFood.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TFood_C2_NAME)
        ));

        // Displays the Table
        List<TFood> listOfRows = (List<TFood>) foodDataHandler.selectAll();
        for (TFood row : listOfRows){
            tableLayoutFood.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Beverage table
     *
     * @param tableLayoutBeverage The Table
     * @param beveragesDataHandler The Data Handler
     */
    public void setTableLayoutTBeverage (TableLayout tableLayoutBeverage, BeveragesDataHandler beveragesDataHandler){
        tableLayoutBeverage.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TClothing_C2_NAME)
        ));

        // Displays the Table
        List<TBeverages> listOfRows = (List<TBeverages>) beveragesDataHandler.selectAll();
        for (TBeverages row : listOfRows){
            tableLayoutBeverage.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Chems table
     *
     * @param tableLayoutChems The Table
     * @param chemDataHandler The Data Handler
     */
    public void setTableLayoutTChems (TableLayout tableLayoutChems, ChemDataHandler chemDataHandler){
        tableLayoutChems.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TArmor_C2_NAME)
        ));

        // Displays the Table
        List<TChem> listOfRows = (List<TChem>) chemDataHandler.selectAll();
        for (TChem row : listOfRows){
            tableLayoutChems.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Ranged Weapons table
     *
     * @param tableLayoutWeponsRanged The Table
     * @param rangedWeaponsDataHandler The Data Handler
     */
    public void setTableLayoutTWeaponsRanged (TableLayout tableLayoutWeponsRanged, RangedWeaponsDataHandler rangedWeaponsDataHandler){
        tableLayoutWeponsRanged.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TArmor_C2_NAME)
        ));

        // Displays the Table
        List<TWeaponsRanged> listOfRows = (List<TWeaponsRanged>) rangedWeaponsDataHandler.selectAll();
        for (TWeaponsRanged row : listOfRows){
            tableLayoutWeponsRanged.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Melee Weapons table
     *
     * @param tableLayoutWeaponsMelee The Table
     * @param meleeWeaponsDataHandler The Data Handler
     */
    public void setTableLayoutTWeaponsMelee (TableLayout tableLayoutWeaponsMelee, MeleeWeaponsDataHandler meleeWeaponsDataHandler){
        tableLayoutWeaponsMelee.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TArmor_C2_NAME)
        ));

        // Displays the Table
        List<TWeaponsMelee> listOfRows = (List<TWeaponsMelee>) meleeWeaponsDataHandler.selectAll();
        for (TWeaponsMelee row : listOfRows){
            tableLayoutWeaponsMelee.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Armor table
     *
     * @param tableLayoutThrownExplosives The Table
     * @param thrownExplosivesWeaponsDataHandler The Data Handler
     */
    public void setTableLayoutTArmor (TableLayout tableLayoutThrownExplosives, ThrownExplosivesWeaponsDataHandler thrownExplosivesWeaponsDataHandler){
        tableLayoutThrownExplosives.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TArmor_C2_NAME)
        ));

        // Displays the Table
        List<TWeaponsThrownExplosives> listOfRows = (List<TWeaponsThrownExplosives>) thrownExplosivesWeaponsDataHandler.selectAll();
        for (TWeaponsThrownExplosives row : listOfRows){
            tableLayoutThrownExplosives.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Oddities table
     *
     * @param tableLayoutOddities The Table
     * @param odditiesDataHandler The Data Handler
     */
    public void setTableLayoutTOddities (TableLayout tableLayoutOddities, OdditiesDataHandler odditiesDataHandler){
        tableLayoutOddities.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TArmor_C2_NAME)
        ));

        // Displays the Table
        List<TOddities> listOfRows = (List<TOddities>) odditiesDataHandler.selectAll();
        for (TOddities row : listOfRows){
            tableLayoutOddities.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates and displays the Junk table
     *
     * @param tableLayoutJunk The Table
     * @param junkDataHandler The Data Handler
     */
    public void setTableLayoutTJunk (TableLayout tableLayoutJunk, JunkDataHandler junkDataHandler){
        tableLayoutJunk.addView(addRow (
                context.getString(R.string.Generic_Col_2d20),
                context.getString(R.string.TFood_C2_NAME)
        ));

        // Displays the Table
        List<TJunk> listOfRows = (List<TJunk>) junkDataHandler.selectAll();
        for (TJunk row : listOfRows){
            tableLayoutJunk.addView(addRow ("" + row.getId(), row.getDrop()));
        }
    }

    /**
     * Generates a row of two columns
     *
     * @param column1 The 1st column
     * @param column2 The 2nd column
     * @return The row
     */
    private TableRow addRow (String column1, String column2){
        TableRow row = new TableRow( context);

        TextView textView = new TextView(context);
        textView.setText(String.valueOf(column1));
        row.addView(textView);

        textView = new TextView(context);
        textView.setText(String.valueOf(column2));
        row.addView(textView);

        return row;
    }

    /**
     * Generates a row of three columns
     *
     * @param column1 The 1st column
     * @param column2 The 2nd column
     * @param column3 The 3rd column
     * @return The row
     */
    private TableRow addRow (String column1, String column2, String column3){
        TableRow row = new TableRow(context);

        TextView textView = new TextView(context);
        textView.setText(String.valueOf(column1));
        row.addView(textView);

        textView = new TextView(context);
        textView.setText(String.valueOf(column2));
        row.addView(textView);

        textView = new TextView(context);
        textView.setText(String.valueOf(column3));
        row.addView(textView);

        return row;
    }
}
