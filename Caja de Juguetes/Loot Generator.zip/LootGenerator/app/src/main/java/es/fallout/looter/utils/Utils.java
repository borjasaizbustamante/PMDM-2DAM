package es.fallout.looter.utils;

/**
 * Static values for Activities
 */
public class Utils {

    // IDs for the Activities
    public static final int ID_MAIN_ACTIVITY = 1;
    public static final int ID_LOOTER_ACTIVITY = 2;
 }
