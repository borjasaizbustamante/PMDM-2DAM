package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TAmmo;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Ammo
 */
public class AmmoDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TAmmo> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public AmmoDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( AmmoDataHandler.class.getName(), "populate " + TABLE_NAME_AMMO);
        TAmmo tAmmo;
        for (int i = 2; i <= 40; i++){
            tAmmo = new TAmmo ();
            tAmmo.setId(i);
            tAmmo.setDrop(context.getString( Utils.getStringId(TABLE_NAME_AMMO + "_C2_F" + i)));
            insert (tAmmo);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_AMMO);
    }

    /**
     * Selects * from table
     *
     * @return List<TAmmo>
     */
    public List<TAmmo> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_AMMO );
        return Utils.downcast (list, TAmmo::new);
    }

    /**
     * Insert into table
     *
     * @param tAmmo The row
     */
    public void insert(TAmmo tAmmo) {
        insert (tAmmo, TABLE_NAME_AMMO, COLUMN_ID, COLUMN_AMMO_QUANTITY);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TAmmo
     */
    public TAmmo selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_AMMO, COLUMN_ID);
        return new TAmmo(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_AMMO, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tAmmo The row
     * @return boolean
     */
    public boolean update(TAmmo tAmmo) {
        return update (tAmmo, TABLE_NAME_AMMO, COLUMN_ID, COLUMN_AMMO_QUANTITY);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_AMMO);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_AMMO);
    }
}
