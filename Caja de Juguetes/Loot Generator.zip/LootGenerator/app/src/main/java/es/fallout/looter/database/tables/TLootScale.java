package es.fallout.looter.database.tables;

/**
 * Table for Scale, Example and Time Taken
 */
public class TLootScale {

    private int id = 0;

    private String scale = null;

    private String example = null;

    private String time = null;

    public TLootScale(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getScale() {
        return scale;
    }

    public void setScale(String scale) {
        this.scale = scale;
    }

    public String getExample() {
        return example;
    }

    public void setExample(String example) {
        this.example = example;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
