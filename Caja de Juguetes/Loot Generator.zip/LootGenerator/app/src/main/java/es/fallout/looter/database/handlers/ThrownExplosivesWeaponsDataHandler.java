package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.tables.TWeaponsThrownExplosives;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Explosive Weapons
 */
public class ThrownExplosivesWeaponsDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TWeaponsThrownExplosives> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public ThrownExplosivesWeaponsDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( GenericIdDropDataHandler.class.getName(), "populate " + TABLE_NAME_WEAPONS_EXPLOSIVES);
        Log.i ( AmmoDataHandler.class.getName(), "populate " + TABLE_NAME_WEAPONS_EXPLOSIVES);
        TWeaponsThrownExplosives tWeaponsThrownExplosives;
        for (int i = 2; i <= 40; i++){
            tWeaponsThrownExplosives = new TWeaponsThrownExplosives();
            tWeaponsThrownExplosives.setId(i);
            tWeaponsThrownExplosives.setDrop(context.getString( Utils.getStringId(TABLE_NAME_WEAPONS_EXPLOSIVES + "_C2_F" + i)));
            insert ( tWeaponsThrownExplosives );
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_WEAPONS_EXPLOSIVES);
    }

    /**
     * Selects * from table
     *
     * @return List<TWeaponsMeleeExplosives>
     */
    public List<TWeaponsThrownExplosives> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_WEAPONS_EXPLOSIVES );
        return Utils.downcast (list, TWeaponsThrownExplosives::new);
    }

    /**
     * Insert into table
     *
     * @param tWeaponsThrownExplosives The row
     */
    public void insert(TWeaponsThrownExplosives tWeaponsThrownExplosives) {
        insert ( tWeaponsThrownExplosives, TABLE_NAME_WEAPONS_EXPLOSIVES, COLUMN_ID, COLUMN_WEAPONS_EXPLOSIVES);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TWeaponsRanged
     */
    public TWeaponsThrownExplosives selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_WEAPONS_EXPLOSIVES, COLUMN_ID);
        return new TWeaponsThrownExplosives(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_WEAPONS_EXPLOSIVES, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tWeaponsThrownExplosives The row
     * @return boolean
     */
    public boolean update(TWeaponsThrownExplosives tWeaponsThrownExplosives) {
        return update ( tWeaponsThrownExplosives, TABLE_NAME_WEAPONS_EXPLOSIVES, COLUMN_ID, COLUMN_WEAPONS_EXPLOSIVES);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_WEAPONS_EXPLOSIVES);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_WEAPONS_EXPLOSIVES);
    }
}
