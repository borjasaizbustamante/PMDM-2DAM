package es.fallout.looter.database.tables;

/**
 * Table for Degree and Difficult
 */
public class TLootDifficulty {

    private int id = 0;

    private String degree = null;

    private int difficulty = 0;

    public TLootDifficulty(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }
}
