package es.fallout.looter.database.handlers;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Data Handler - Superclass for all the Data Base
 */
public class DataHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "FalloutLooterGenerator.db";

    protected static final String TABLE_NAME_LOOT_DIFFICULTY = "TLootDifficulty";
    protected static final String COLUMN_ID = "id";
    protected static final String COLUMN_DEGREE = "degree";
    protected static final String COLUMN_DIFFICULTY = "difficulty";

    protected static final String TABLE_NAME_LOOT_SCALE = "TLootScale";
    protected static final String COLUMN_SCALE = "scale";
    protected static final String COLUMN_EXAMPLE = "example";
    protected static final String COLUMN_TIME = "time";

    protected static final String TABLE_NAME_AMMO = "TAmmo";
    protected static final String COLUMN_AMMO_QUANTITY = "ammo";

    protected static final String TABLE_NAME_ARMOR = "TArmor";
    protected static final String COLUMN_ARMOR = "armor";

    protected static final String TABLE_NAME_CLOTHING = "TClothing";
    protected static final String COLUMN_CLOTHING = "clothing";

    protected static final String TABLE_NAME_FOOD = "TFood";
    protected static final String COLUMN_FOOD_NAME = "foodName";

    protected static final String TABLE_NAME_BEVERAGES = "TBeverages";
    protected static final String COLUMN_BEVERAGE = "beverage";

    protected static final String TABLE_NAME_CHEM = "TChems";
    protected static final String COLUMN_CHEM = "chem";

    protected static final String TABLE_NAME_WEAPONS_RANGED = "TWeaponsRanged";
    protected static final String COLUMN_WEAPONS_RANGED = "rangedWeapon";

    protected static final String TABLE_NAME_WEAPONS_MELEE = "TWeaponsMelee";
    protected static final String COLUMN_WEAPONS_MELEE = "meleeWeapon";

    protected static final String TABLE_NAME_WEAPONS_EXPLOSIVES = "TWeaponsExplosives";
    protected static final String COLUMN_WEAPONS_EXPLOSIVES = "explosiveWeapon";

    protected static final String TABLE_NAME_ODDITIES = "TOddities";
    protected static final String COLUMN_ODDITIES = "oddity";

    protected static final String TABLE_NAME_JUNK = "TJunk";
    protected static final String COLUMN_JUNK_NAME = "JunkName";

    protected Context context;

    /**
     * Builder
     *
     * @param context Teh context
     */
    public DataHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    //------------------------------ onCreate ------------------------------//

    /**
     * Called if the Data Base does not exist. Creates the Data Base and tables.
     *
     * @param sQLiteDatabase The data base
     */
    @Override
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        onCreateDegreeDifficulty(sQLiteDatabase);
        onCreateScaleExampleTime(sQLiteDatabase);
        onCreateAmmo(sQLiteDatabase);
        onCreateArmor(sQLiteDatabase);
        onCreateClothing(sQLiteDatabase);
        onCreateFood(sQLiteDatabase);
        onCreateBeverages(sQLiteDatabase);
        onCreateChem(sQLiteDatabase);
        onCreateWeaponsRanged(sQLiteDatabase);
        onCreateWeaponsMelee(sQLiteDatabase);
        onCreateWeaponsExplosives(sQLiteDatabase);
        onCreateOddities(sQLiteDatabase);
        onCreateJunk(sQLiteDatabase);
    }

    /**
     * Creates the DegreeDifficulty Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateDegreeDifficulty (SQLiteDatabase sQLiteDatabase){
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_LOOT_DIFFICULTY );
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_LOOT_DIFFICULTY + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_DEGREE + " TEXT, " +
                COLUMN_DIFFICULTY + " INTEGER" +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the ScaleExampleTime Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateScaleExampleTime(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_LOOT_SCALE );
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_LOOT_SCALE + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_SCALE + " TEXT, " +
                COLUMN_EXAMPLE + " TEXT, " +
                COLUMN_TIME + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Ammo Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateAmmo(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_AMMO);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_AMMO + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_AMMO_QUANTITY + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Armor Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateArmor(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_ARMOR);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_ARMOR + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_ARMOR + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Clothing Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateClothing(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_CLOTHING);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_CLOTHING + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_CLOTHING + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Beverages Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateFood(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_BEVERAGES);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_FOOD + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_FOOD_NAME + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Beverages Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateBeverages(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_BEVERAGES);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_BEVERAGES + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_BEVERAGE + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Chem Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateChem(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_CHEM );
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_CHEM + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_CHEM + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Weapons Ranged Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateWeaponsRanged(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_WEAPONS_RANGED);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_WEAPONS_RANGED + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_WEAPONS_RANGED + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Weapons Melee Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateWeaponsMelee(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_WEAPONS_MELEE);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_WEAPONS_MELEE + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_WEAPONS_MELEE + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Weapons Explosives Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateWeaponsExplosives(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_WEAPONS_EXPLOSIVES);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_WEAPONS_EXPLOSIVES + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_WEAPONS_EXPLOSIVES + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Oddities Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateOddities(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_ODDITIES);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_ODDITIES + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_ODDITIES + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    /**
     * Creates the Junk Table
     *
     * @param sQLiteDatabase The data base
     */
    private void onCreateJunk(SQLiteDatabase sQLiteDatabase) {
        Log.i ( DataHandler.class.getName(), "onCreate " + TABLE_NAME_JUNK);
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_JUNK + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_JUNK_NAME + " TEXT " +
                ")";
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    //------------------------------ onUpgrade ------------------------------//

    /**
     * Called when updating the Data Base
     *
     * @param sQLiteDatabase The data base
     * @param oldVersion The old version
     * @param newVersion The new version
     */
    @Override
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int oldVersion, int newVersion){
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_LOOT_DIFFICULTY );
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_LOOT_DIFFICULTY );
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_LOOT_SCALE );
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_LOOT_SCALE );
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_AMMO);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_AMMO);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_ARMOR);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_ARMOR);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_CLOTHING);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_CLOTHING);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_FOOD);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_FOOD);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_BEVERAGES);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_BEVERAGES);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_CHEM );
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_CHEM );
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_WEAPONS_RANGED);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_WEAPONS_RANGED);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_WEAPONS_MELEE);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_WEAPONS_MELEE);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_WEAPONS_EXPLOSIVES);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_WEAPONS_EXPLOSIVES);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_ODDITIES);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_ODDITIES);
        Log.i ( DataHandler.class.getName(), "onUpgrade " + TABLE_NAME_JUNK);
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_JUNK);
        onCreate(sQLiteDatabase);
    }

    //------------------------------ ifExist / ifEmpty ------------------------------//

    /**
     * Returns true if the table exists, false otherwise
     *
     * @param tableName The table name
     * @return True or False
     */
    protected boolean ifTableExists(String tableName) {
        boolean ret = false;
        Cursor cursor = null;
        try {
            SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
            String query = "select DISTINCT tbl_name from sqlite_master where tbl_name = '" + tableName + "'";
            cursor = sQLiteDatabase.rawQuery( query, null );
            if (cursor != null) {
                if (cursor.getCount() > 0) {
                    ret = true;
                }
            }
        } catch (Exception e) {
            // Nothing to do here...
        } finally{
            try{
                assert cursor != null;
                cursor.close();
            } catch (NullPointerException e) {
                // Nothing to do here...
            }
        }
        return ret;
    }

    /**
     * Returns true if the table is empty, false otherwise
     *
     * @param tableName Teh table name
     * @return True or False
     */
    protected boolean isEmpty(String tableName){
        boolean ret = true;
        Cursor cursor = null;
        try {
            SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
            cursor = sQLiteDatabase.rawQuery( "SELECT count(*) FROM (select 0 from " + tableName + " limit 1)", null );
            cursor.moveToFirst();
            int count = cursor.getInt( 0 );
            if (count > 0) {
                ret = false;
            }
        } catch (Exception e) {
            // Nothing to do here...
        }
        finally {
            try {
                assert cursor != null;
                cursor.close();
            } catch (Exception e) {
                // Nothing to do here...
            }
        }
        return ret;
    }
}
