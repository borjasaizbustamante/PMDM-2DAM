package es.fallout.looter.utils;

import java.util.Random;

/**
 * Dice simulator
 */
public class Dice {

    private static final Random generator = new Random();

    /**
     * Generates a random number between 1 and 20
     *
     * @return The random number
     */
    public static int rollD20() {
        return 1 + generator.nextInt(20);
    }

    /**
     * Generates a random number between 2 and 40
     *
     * @return The random number
     */
    public static int roll2D20() {
        return (1 + generator.nextInt(20)) + (1 + generator.nextInt(20));
    }

    /**
     * Generates a random number between 1 and 6
     *
     * @return The random number
     */
    public static int roll1D6() {
        return 1 + generator.nextInt(6);
    }

    /**
     * Junk - Generates a random number between 3 and 490
     *
     * @return The random number
     */
    public static int rollJunk() {
        return getRandomNumber(3, 490);
    }

    /**
     * Generates a random number between min and max
     *
     * @param min The min value
     * @param max The max value
     * @return The random number
     */
    private static int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }
}
