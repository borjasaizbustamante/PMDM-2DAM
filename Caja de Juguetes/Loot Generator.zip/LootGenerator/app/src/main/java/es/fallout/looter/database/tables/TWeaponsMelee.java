package es.fallout.looter.database.tables;

/**
 * Weapons (Melee) table
 */
public class TWeaponsMelee extends TGenericTwoColumnDrop{

    public TWeaponsMelee(){}

    public TWeaponsMelee(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
