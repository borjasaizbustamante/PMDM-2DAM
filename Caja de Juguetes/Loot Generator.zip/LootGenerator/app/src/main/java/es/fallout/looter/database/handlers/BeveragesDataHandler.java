package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TBeverages;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Beverages
 */
public class BeveragesDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TBeverages> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public BeveragesDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( BeveragesDataHandler.class.getName(), "populate " + TABLE_NAME_BEVERAGES);
        TBeverages tBeverages;
        for (int i = 2; i <= 40; i++){
            tBeverages = new TBeverages ();
            tBeverages.setId(i);
            tBeverages.setDrop(context.getString( Utils.getStringId(TABLE_NAME_BEVERAGES + "_C2_F" + i)));
            insert (tBeverages);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_BEVERAGES);
    }

    /**
     * Selects * from table
     *
     * @return List<TBeverages>
     */
    public List<TBeverages> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_BEVERAGES );
        return Utils.downcast (list, TBeverages::new);
    }

    /**
     * Insert into table
     *
     * @param tBeverages The row
     */
    public void insert(TBeverages tBeverages) {
        insert (tBeverages, TABLE_NAME_BEVERAGES, COLUMN_ID, COLUMN_BEVERAGE);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TBeverages
     */
    public TBeverages selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_BEVERAGES, COLUMN_ID);
        return new TBeverages(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_BEVERAGES, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tBeverages The row
     * @return boolean
     */
    public boolean update(TBeverages tBeverages) {
        return update (tBeverages, TABLE_NAME_BEVERAGES, COLUMN_ID, COLUMN_BEVERAGE);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_BEVERAGES);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_BEVERAGES);
    }
}
