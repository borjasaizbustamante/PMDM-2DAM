package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TFood;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Food
 */
public class FoodDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TFood> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public FoodDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( FoodDataHandler.class.getName(), "populate " + TABLE_NAME_FOOD);
        TFood tFood;
        for (int i = 2; i <= 40; i++){
            tFood = new TFood ();
            tFood.setId(i);
            tFood.setDrop(context.getString( Utils.getStringId(TABLE_NAME_FOOD + "_C2_F" + i)));
            insert (tFood);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_FOOD);
    }

    /**
     * Selects * from table
     *
     * @return List<TFood>
     */
    public List<TFood> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_FOOD );
        return Utils.downcast (list, TFood::new);
    }

    /**
     * Insert into table
     *
     * @param tFood The row
     */
    public void insert(TFood tFood) {
        insert (tFood, TABLE_NAME_FOOD, COLUMN_ID, COLUMN_FOOD_NAME);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TFood
     */
    public TFood selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_FOOD, COLUMN_ID);
        return new TFood(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_FOOD, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tFood The row
     * @return boolean
     */
    public boolean update(TFood tFood) {
        return update (tFood, TABLE_NAME_FOOD, COLUMN_ID, COLUMN_FOOD_NAME);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_FOOD);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_FOOD);
    }
}
