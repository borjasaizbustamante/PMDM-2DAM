package es.fallout.looter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.bumptech.glide.Glide;

import es.fallout.looter.database.handlers.AmmoDataHandler;
import es.fallout.looter.database.handlers.ArmorDataHandler;
import es.fallout.looter.database.handlers.BeveragesDataHandler;
import es.fallout.looter.database.handlers.ChemDataHandler;
import es.fallout.looter.database.handlers.ClothingDataHandler;
import es.fallout.looter.database.handlers.FoodDataHandler;
import es.fallout.looter.database.handlers.JunkDataHandler;
import es.fallout.looter.database.handlers.LootDifficultyDataHandler;
import es.fallout.looter.database.handlers.LootScaleDataHandler;
import es.fallout.looter.database.handlers.MeleeWeaponsDataHandler;
import es.fallout.looter.database.handlers.OdditiesDataHandler;
import es.fallout.looter.database.handlers.RangedWeaponsDataHandler;
import es.fallout.looter.database.handlers.ThrownExplosivesWeaponsDataHandler;
import es.fallout.looter.utils.Utils;

/**
 * Activity for loading the databases
 */
public class MainActivity extends AppCompatActivity {

    private ProgressBar progressBar = null;

    /**
     * AsyncTask<Params, Progress, Result>
     */
    class MainActivityAsyncTask extends AsyncTask<Integer, Integer, String> {

        /**
         * Method is called before task execution on UI thread. Disables the user interaction
         * with the screen. Blocks user touch events
         */
        @Override
        protected void onPreExecute() {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }

        /**
         * Method is called just after execution of onPreExecute() in background thread.
         *
         * @param params The params
         * @return Empty string
         */
        @Override
        protected String doInBackground(Integer... params) {
            populateDataBase ();
            return "";
        }

        /**
         * Populates data base
         */
        private void populateDataBase (){

            // TABLE - table LootDifficulty
            LootDifficultyDataHandler lootDifficultyDataHandler = new LootDifficultyDataHandler(MainActivity.this);
            if (lootDifficultyDataHandler.isEmpty())
                lootDifficultyDataHandler.populate();
            progressBar.setProgress(7);

            // TABLE - table LootScale
            LootScaleDataHandler lootScaleDataHandler = new LootScaleDataHandler(MainActivity.this);
            if (lootScaleDataHandler.isEmpty())
                lootScaleDataHandler.populate();
            progressBar.setProgress(14);

            // TABLE - table Ammo
            AmmoDataHandler ammoDataHandler = new AmmoDataHandler(MainActivity.this);
            if (ammoDataHandler.isEmpty())
                ammoDataHandler.populate();
            progressBar.setProgress(21);

            // TABLE - table Armor
            ArmorDataHandler armorDataHandler = new ArmorDataHandler(MainActivity.this);
            if (armorDataHandler.isEmpty())
                armorDataHandler.populate();
            progressBar.setProgress(28);

            // TABLE - table Clothing
            ClothingDataHandler clothingDataHandler = new ClothingDataHandler(MainActivity.this);
            if (clothingDataHandler.isEmpty())
                clothingDataHandler.populate();
            progressBar.setProgress(35);

            // TABLE - table Food
            FoodDataHandler foodDataHandler = new FoodDataHandler(MainActivity.this);
            if (foodDataHandler.isEmpty())
                foodDataHandler.populate();
            progressBar.setProgress(42);

            // TABLE - table Beverages
            BeveragesDataHandler beveragesDataHandler = new BeveragesDataHandler(MainActivity.this);
            if (beveragesDataHandler.isEmpty())
                beveragesDataHandler.populate();
            progressBar.setProgress(49);

            // TABLE - table Chem
            ChemDataHandler chemDataHandler = new ChemDataHandler(MainActivity.this);
            if (chemDataHandler.isEmpty())
                chemDataHandler.populate();
            progressBar.setProgress(56);

            // TABLE - table Ranged Weapons
            RangedWeaponsDataHandler rangedWeaponsDataHandler = new RangedWeaponsDataHandler(MainActivity.this);
            if (rangedWeaponsDataHandler.isEmpty())
                rangedWeaponsDataHandler.populate();
            progressBar.setProgress(63);

            // TABLE - table Melee Weapons
            MeleeWeaponsDataHandler meleeWeaponsDataHandler = new MeleeWeaponsDataHandler(MainActivity.this);
            if (meleeWeaponsDataHandler.isEmpty())
                meleeWeaponsDataHandler.populate();
            progressBar.setProgress(70);

            // TABLE - table Explosives
            ThrownExplosivesWeaponsDataHandler thrownExplosivesWeaponsDataHandler = new ThrownExplosivesWeaponsDataHandler(MainActivity.this);
            if (thrownExplosivesWeaponsDataHandler.isEmpty())
                thrownExplosivesWeaponsDataHandler.populate();
            progressBar.setProgress(77);

            // TABLE - table Oddities
            OdditiesDataHandler odditiesDataHandler = new OdditiesDataHandler(MainActivity.this);
            if (odditiesDataHandler.isEmpty())
                odditiesDataHandler.populate();
            progressBar.setProgress(84);

            // TABLE - table Junk
            JunkDataHandler junkDataHandler = new JunkDataHandler(MainActivity.this);
            if (junkDataHandler.isEmpty())
                junkDataHandler.populate();
            progressBar.setProgress(93);

            progressBar.setProgress(100);
        }

        /**
         * Method is called on UI thread after calling publishProgress(Progress...) within the
         * doInBackground(Params...) for any status update like progress bar.
         *
         * @param values Teh values
         */
        @Override
        protected void onProgressUpdate(Integer... values) {
            progressBar.setProgress(values[0]);
        }

        /**
         * Method is called on UI thread just after completion of doInBackground(Params...) and the
         * result is passed to onPostExecute(Result). Enables the user interaction with the screen.
         * Unblocks user touch events.
         *
         * @param result the result
         */
        @Override
        protected void onPostExecute(String result) {
            progressBar.setVisibility(View.GONE);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        (findViewById(R.id.constraintLayout)).setBackgroundColor(Color.parseColor("#000000"));

        // Touch the screen to go...
        ConstraintLayout constraintLayout = findViewById(R.id.constraintLayout);
        constraintLayout.setOnTouchListener(
                (v, m) -> {
                    Intent intent = new Intent( MainActivity.this, LooterActivity.class );
                    startActivityForResult( intent, Utils.ID_LOOTER_ACTIVITY );
                    return true;
                }
        );

        // Vault boy walking
        ImageView imageView = findViewById(R.id.vaultboyGif);
        Glide.with(this).load(R.raw.vaultboywalking).into(imageView);

        // The progress bar
        progressBar = findViewById( R.id.datBaseLoadingBar);
        progressBar.setMax(100);
        progressBar.setProgress(0);

        // Loading Data Base
        new MainActivityAsyncTask().execute();
    }
}