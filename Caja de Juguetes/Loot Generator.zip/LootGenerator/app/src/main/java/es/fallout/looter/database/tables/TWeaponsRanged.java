package es.fallout.looter.database.tables;

/**
 * Weapons (Ranged) table
 */
public class TWeaponsRanged extends TGenericTwoColumnDrop{

    public TWeaponsRanged(){}

    public TWeaponsRanged(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
