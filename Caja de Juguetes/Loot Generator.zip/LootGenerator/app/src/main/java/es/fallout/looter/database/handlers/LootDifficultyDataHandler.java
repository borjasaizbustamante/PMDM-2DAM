package es.fallout.looter.database.handlers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import es.fallout.looter.R;
import es.fallout.looter.database.tables.TLootDifficulty;

/**
 * Loot Difficulty Table
 */
public class LootDifficultyDataHandler extends DataHandler implements HandlerInterface <TLootDifficulty>{

    public LootDifficultyDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    public void populate (){
        Log.i ( LootDifficultyDataHandler.class.getName(), "populate " + TABLE_NAME_LOOT_DIFFICULTY );
        TLootDifficulty tLootDifficulty;

        tLootDifficulty = new TLootDifficulty();
        tLootDifficulty.setId(1);
        tLootDifficulty.setDegree(context.getString( R.string.TDegreeDifficulty_C1_F1));
        tLootDifficulty.setDifficulty(Integer.parseInt(context.getString( R.string.TDegreeDifficulty_C2_F1)));
        insert ( tLootDifficulty );

        tLootDifficulty = new TLootDifficulty();
        tLootDifficulty.setId(2);
        tLootDifficulty.setDegree(context.getString( R.string.TDegreeDifficulty_C1_F2));
        tLootDifficulty.setDifficulty(Integer.parseInt(context.getString( R.string.TDegreeDifficulty_C2_F2 )));
        insert( tLootDifficulty );

        tLootDifficulty = new TLootDifficulty();
        tLootDifficulty.setId(3);
        tLootDifficulty.setDegree(context.getString( R.string.TDegreeDifficulty_C1_F3));
        tLootDifficulty.setDifficulty(Integer.parseInt(context.getString( R.string.TDegreeDifficulty_C2_F3)));
        insert( tLootDifficulty );

        tLootDifficulty = new TLootDifficulty();
        tLootDifficulty.setId(4);
        tLootDifficulty.setDegree(context.getString( R.string.TDegreeDifficulty_C1_F4));
        tLootDifficulty.setDifficulty(Integer.parseInt(context.getString( R.string.TDegreeDifficulty_C2_F4)));
        insert( tLootDifficulty );
    }

    public void drop (){
        Log.i ( LootDifficultyDataHandler.class.getName(), "drop " + TABLE_NAME_LOOT_DIFFICULTY );
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase ();
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_LOOT_DIFFICULTY );
    }

    public List<TLootDifficulty> selectAll () {
        Log.i ( LootDifficultyDataHandler.class.getName(), "select * from " + TABLE_NAME_LOOT_DIFFICULTY );
        List<TLootDifficulty> ret = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_NAME_LOOT_DIFFICULTY;
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery(query, null);
        TLootDifficulty tLootDifficulty;
        while (cursor.moveToNext()) {
            tLootDifficulty = new TLootDifficulty();
            tLootDifficulty.setId(cursor.getInt(0));
            tLootDifficulty.setDegree(cursor.getString(1));
            tLootDifficulty.setDifficulty(cursor.getInt(2));
            ret.add( tLootDifficulty );
        }
        cursor.close();
        sQLiteDatabase.close();
        return ret;
    }

    public void insert (TLootDifficulty tLootDifficulty) {
        Log.i ( LootDifficultyDataHandler.class.getName(), "insert " + tLootDifficulty.getId() + " into " + TABLE_NAME_LOOT_DIFFICULTY );
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, tLootDifficulty.getId());
        values.put(COLUMN_DEGREE, tLootDifficulty.getDegree());
        values.put(COLUMN_DIFFICULTY, tLootDifficulty.getDifficulty());

        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.insert( TABLE_NAME_LOOT_DIFFICULTY, null, values);
        sQLiteDatabase.close();
    }

    public TLootDifficulty selectById (int id) {
        Log.i ( LootDifficultyDataHandler.class.getName(), "select * from " + TABLE_NAME_LOOT_DIFFICULTY + " where " + id);
        String query = "Select * FROM " + TABLE_NAME_LOOT_DIFFICULTY + " WHERE " + COLUMN_ID +
                " = " + "'" + id + "'";
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery(query, null);

        TLootDifficulty tLootDifficulty = new TLootDifficulty();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            tLootDifficulty.setId(cursor.getInt(0));
            tLootDifficulty.setDegree(cursor.getString(1));
            tLootDifficulty.setDifficulty(cursor.getInt(2));
            cursor.close();
        } else {
            tLootDifficulty = null;
        }
        sQLiteDatabase.close();
        return tLootDifficulty;
    }

    public int deleteById (int id) {
        Log.i ( LootDifficultyDataHandler.class.getName(), "delete from " + TABLE_NAME_LOOT_DIFFICULTY + " where Id = " + id);
        int ret;
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        TLootDifficulty tLootDifficulty = new TLootDifficulty();
        tLootDifficulty.setId(id);
        ret = sQLiteDatabase.delete( TABLE_NAME_LOOT_DIFFICULTY, COLUMN_ID + "=?",
                new String[] {
                        String.valueOf( tLootDifficulty.getId())
                });
        sQLiteDatabase.close();
        return ret;
    }

    public boolean update (TLootDifficulty tLootDifficulty) {
        Log.i ( LootDifficultyDataHandler.class.getName(), "update " + TABLE_NAME_LOOT_DIFFICULTY + " set ...");
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(COLUMN_ID, tLootDifficulty.getId());
        args.put(COLUMN_DEGREE, tLootDifficulty.getDegree());
        args.put(COLUMN_DIFFICULTY, tLootDifficulty.getDifficulty());
        String whereClause = COLUMN_ID + "=" + tLootDifficulty.getId();
        return sQLiteDatabase.update( TABLE_NAME_LOOT_DIFFICULTY, args, whereClause, null) > 0;
    }

    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_LOOT_DIFFICULTY);
    }

    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_LOOT_DIFFICULTY);
    }
}
