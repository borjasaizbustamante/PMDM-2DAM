package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TJunk;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Junk
 */
public class JunkDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TJunk> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public JunkDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( JunkDataHandler.class.getName(), "populate " + TABLE_NAME_JUNK);
        TJunk tJunk;
        for (int i = 3; i <= 490; i++){
            tJunk = new TJunk ();
            tJunk.setId(i);
            tJunk.setDrop(context.getString( Utils.getStringId(TABLE_NAME_JUNK + "_C2_F" + i)));
            insert (tJunk);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_JUNK);
    }

    /**
     * Selects * from table
     *
     * @return List<TJunk>
     */
    public List<TJunk> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_JUNK );
        return Utils.downcast (list, TJunk::new);
    }

    /**
     * Insert into table
     *
     * @param tJunk The row
     */
    public void insert(TJunk tJunk) {
        insert (tJunk, TABLE_NAME_JUNK, COLUMN_ID, COLUMN_JUNK_NAME);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TJunk
     */
    public TJunk selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_JUNK, COLUMN_ID);
        return new TJunk(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_JUNK, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tJunk The row
     * @return boolean
     */
    public boolean update(TJunk tJunk) {
        return update (tJunk, TABLE_NAME_JUNK, COLUMN_ID, COLUMN_JUNK_NAME);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_JUNK);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_JUNK);
    }
}
