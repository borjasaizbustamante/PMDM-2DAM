package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TArmor;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Armor
 */
public class ArmorDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TArmor> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public ArmorDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( GenericIdDropDataHandler.class.getName(), "populate " + TABLE_NAME_ARMOR);
        Log.i ( AmmoDataHandler.class.getName(), "populate " + TABLE_NAME_ARMOR);
        TArmor tArmor;
        for (int i = 2; i <= 40; i++){
            tArmor = new TArmor ();
            tArmor.setId(i);
            tArmor.setDrop(context.getString( Utils.getStringId(TABLE_NAME_ARMOR + "_C2_F" + i)));
            insert (tArmor);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_ARMOR);
    }

    /**
     * Selects * from table
     *
     * @return List<TAmmo>
     */
    public List<TArmor> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_ARMOR );
        return Utils.downcast (list, TArmor::new);
    }

    /**
     * Insert into table
     *
     * @param tArmor The row
     */
    public void insert(TArmor tArmor) {
        insert (tArmor, TABLE_NAME_ARMOR, COLUMN_ID, COLUMN_ARMOR);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TArmor
     */
    public TArmor selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_ARMOR, COLUMN_ID);
        return new TArmor(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_ARMOR, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tArmor The row
     * @return boolean
     */
    public boolean update(TArmor tArmor) {
        return update (tArmor, TABLE_NAME_ARMOR, COLUMN_ID, COLUMN_ARMOR);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_ARMOR);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_ARMOR);
    }
}
