package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TWeaponsRanged;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Ranged Weapons
 */
public class RangedWeaponsDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TWeaponsRanged> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public RangedWeaponsDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( GenericIdDropDataHandler.class.getName(), "populate " + TABLE_NAME_WEAPONS_RANGED);
        Log.i ( AmmoDataHandler.class.getName(), "populate " + TABLE_NAME_WEAPONS_RANGED);
        TWeaponsRanged tWeaponsRanged;
        for (int i = 2; i <= 40; i++){
            tWeaponsRanged = new TWeaponsRanged ();
            tWeaponsRanged.setId(i);
            tWeaponsRanged.setDrop(context.getString( Utils.getStringId(TABLE_NAME_WEAPONS_RANGED + "_C2_F" + i)));
            insert (tWeaponsRanged);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_WEAPONS_RANGED);
    }

    /**
     * Selects * from table
     *
     * @return List<TWeaponsRanged>
     */
    public List<TWeaponsRanged> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_WEAPONS_RANGED );
        return Utils.downcast (list, TWeaponsRanged::new);
    }

    /**
     * Insert into table
     *
     * @param tWeaponsRanged The row
     */
    public void insert(TWeaponsRanged tWeaponsRanged) {
        insert (tWeaponsRanged, TABLE_NAME_WEAPONS_RANGED, COLUMN_ID, COLUMN_WEAPONS_RANGED );
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TWeaponsRanged
     */
    public TWeaponsRanged selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_WEAPONS_RANGED, COLUMN_ID);
        return new TWeaponsRanged(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_WEAPONS_RANGED, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tWeaponsRanged The row
     * @return boolean
     */
    public boolean update(TWeaponsRanged tWeaponsRanged) {
        return update (tWeaponsRanged, TABLE_NAME_WEAPONS_RANGED, COLUMN_ID, COLUMN_WEAPONS_RANGED );
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_WEAPONS_RANGED);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_WEAPONS_RANGED);
    }
}
