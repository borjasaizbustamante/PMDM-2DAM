package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.tables.TOddities;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Oddities
 */
public class OdditiesDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TOddities> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public OdditiesDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( OdditiesDataHandler.class.getName(), "populate " + TABLE_NAME_ODDITIES);
        TOddities tOddities;
        for (int i = 3; i <= 60; i++){
            tOddities = new TOddities ();
            tOddities.setId(i);
            tOddities.setDrop(context.getString( Utils.getStringId(TABLE_NAME_ODDITIES + "_C2_F" + i)));
            insert (tOddities);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_AMMO);
    }

    /**
     * Selects * from table
     *
     * @return List<TOddities>
     */
    public List<TOddities> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_ODDITIES );
        return Utils.downcast (list, TOddities::new);
    }

    /**
     * Insert into table
     *
     * @param tOddities The row
     */
    public void insert(TOddities tOddities) {
        insert (tOddities, TABLE_NAME_ODDITIES, COLUMN_ID, COLUMN_ODDITIES);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TOddities
     */
    public TOddities selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_ODDITIES, COLUMN_ID);
        return new TOddities(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_ODDITIES, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tOddities The row
     * @return boolean
     */
    public boolean update(TOddities tOddities) {
        return update (tOddities, TABLE_NAME_ODDITIES, COLUMN_ID, COLUMN_ODDITIES);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_ODDITIES);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_ODDITIES);
    }
}
