package es.fallout.looter;

import android.os.Bundle;
import android.widget.TableLayout;

import androidx.appcompat.app.AppCompatActivity;

import es.fallout.looter.database.handlers.AmmoDataHandler;
import es.fallout.looter.database.handlers.ArmorDataHandler;
import es.fallout.looter.database.handlers.LootDifficultyDataHandler;
import es.fallout.looter.database.handlers.LootScaleDataHandler;
import es.fallout.looter.ui.TableLayoutsHandler;

public class TableActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_table );

        TableLayoutsHandler tableLayoutsHandler = new TableLayoutsHandler( this );

        LootDifficultyDataHandler lootDifficultyDataHandler = new LootDifficultyDataHandler(this);
        TableLayout tableLayoutDegreeDifficulty = findViewById( R.id.tableLayoutTDegreeDifficulty );
        tableLayoutDegreeDifficulty.setShrinkAllColumns( true );
        tableLayoutDegreeDifficulty.setStretchAllColumns( true );
        tableLayoutsHandler.setTableLayoutTDegreeDifficulty( tableLayoutDegreeDifficulty, lootDifficultyDataHandler );

        LootScaleDataHandler lootScaleDataHandler = new LootScaleDataHandler(this);
        TableLayout tableLayoutScaleExampleTime = findViewById( R.id.tableLayoutTScaleExampleTime );
        tableLayoutScaleExampleTime.setShrinkAllColumns( true );
        tableLayoutScaleExampleTime.setStretchAllColumns( true );
        tableLayoutsHandler.setTableLayoutTScaleExampleTime( tableLayoutScaleExampleTime, lootScaleDataHandler );

        AmmoDataHandler ammoDataHandler = new AmmoDataHandler(this);
        TableLayout tableLayoutAmmo = findViewById( R.id.tableLayoutAmmo );
        tableLayoutAmmo.setShrinkAllColumns( true );
        tableLayoutAmmo.setStretchAllColumns( true );
        tableLayoutsHandler.setTableLayoutTAmmo( tableLayoutAmmo, ammoDataHandler );

        ArmorDataHandler armorDataHandler = new ArmorDataHandler(this);
        TableLayout tableLayoutArmor = findViewById( R.id.tableLayoutTArmor );
        tableLayoutArmor.setShrinkAllColumns( true );
        tableLayoutArmor.setStretchAllColumns( true );
        tableLayoutsHandler.setTableLayoutTArmor( tableLayoutArmor, armorDataHandler );
    }
}