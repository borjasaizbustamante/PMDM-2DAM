package es.fallout.looter;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import es.fallout.looter.database.handlers.AmmoDataHandler;
import es.fallout.looter.database.handlers.ArmorDataHandler;
import es.fallout.looter.database.handlers.BeveragesDataHandler;
import es.fallout.looter.database.handlers.ChemDataHandler;
import es.fallout.looter.database.handlers.ClothingDataHandler;
import es.fallout.looter.database.handlers.FoodDataHandler;
import es.fallout.looter.database.handlers.JunkDataHandler;
import es.fallout.looter.database.handlers.MeleeWeaponsDataHandler;
import es.fallout.looter.database.handlers.OdditiesDataHandler;
import es.fallout.looter.database.handlers.RangedWeaponsDataHandler;
import es.fallout.looter.database.handlers.ThrownExplosivesWeaponsDataHandler;
import es.fallout.looter.database.tables.TAmmo;
import es.fallout.looter.database.tables.TArmor;
import es.fallout.looter.database.tables.TBeverages;
import es.fallout.looter.database.tables.TChem;
import es.fallout.looter.database.tables.TClothing;
import es.fallout.looter.database.tables.TFood;
import es.fallout.looter.database.tables.TJunk;
import es.fallout.looter.database.tables.TOddities;
import es.fallout.looter.database.tables.TWeaponsMelee;
import es.fallout.looter.database.tables.TWeaponsRanged;
import es.fallout.looter.database.tables.TWeaponsThrownExplosives;
import es.fallout.looter.utils.Dice;

/**
 * Activity for rolling dices on tables
 */
public class LooterActivity extends AppCompatActivity {

    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_looter );

        (findViewById(R.id.constraintLayout)).setBackgroundColor( Color.parseColor("#000000"));
        (findViewById(R.id.resultScrollView)).setBackgroundColor( Color.parseColor("#ffffff"));

        resultTextView = findViewById( R.id.ResultTextView);

        // Bare minimum loot added... 1 Clothing, 2 Food, 1 Beverages, 2 Junk
        resultTextView.setText(addBareMinimumLoot());

        // Buttons
        findViewById(R.id.idButtonAmmo).setOnClickListener(ButtonAmmoListener);
        findViewById(R.id.idButtonArmor).setOnClickListener(ButtonArmorListener);
        findViewById(R.id.idButtonClothing).setOnClickListener(ButtonClothingListener);
        findViewById(R.id.idButtonFood).setOnClickListener(ButtonFoodListener);
        findViewById(R.id.idButtonBeverages).setOnClickListener(ButtonBeveragesListener);
        findViewById(R.id.idButtonChems).setOnClickListener( ButtonChemListener );
        findViewById(R.id.idButtonRanged).setOnClickListener(ButtonRangedListener);
        findViewById(R.id.idButtonMelee).setOnClickListener(ButtonMeleeListener);
        findViewById(R.id.idButtonExplosives).setOnClickListener(ButtonExplosivesListener);
        findViewById(R.id.idButtonOddities).setOnClickListener(ButtonOdditiesListener);
        findViewById(R.id.idButtonJunk).setOnClickListener(ButtonJunkListener);
        findViewById(R.id.idButtonReset).setOnClickListener(ButtonResetListener);
    }

    /**
     * Button Ammo Listener
     */
    private final View.OnClickListener ButtonAmmoListener = v -> {
        AmmoDataHandler ammoDataHandler = new AmmoDataHandler(LooterActivity.this);
        TAmmo tAmmo = ammoDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tAmmo.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Armor Listener
     */
    private final View.OnClickListener ButtonArmorListener = v -> {
        ArmorDataHandler armorDataHandler = new ArmorDataHandler(LooterActivity.this);
        TArmor tArmor = armorDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tArmor.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Clothing Listener
     */
    private final View.OnClickListener ButtonClothingListener = v -> {
        ClothingDataHandler clothingDataHandler = new ClothingDataHandler(LooterActivity.this);
        TClothing tClothing = clothingDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tClothing.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Food Listener
     */
    private final View.OnClickListener ButtonFoodListener = v -> {
        FoodDataHandler foodDataHandler = new FoodDataHandler(LooterActivity.this);
        TFood tFood = foodDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tFood.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Beverages Listener
     */
    private final View.OnClickListener ButtonBeveragesListener = v -> {
        BeveragesDataHandler beveragesDataHandler = new BeveragesDataHandler(LooterActivity.this);
        TBeverages tBeverages = beveragesDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tBeverages.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Chem Listener
     */
    private final View.OnClickListener ButtonChemListener = v -> {
        ChemDataHandler chemDataHandler = new ChemDataHandler(LooterActivity.this);
        TChem tChem = chemDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tChem.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Ranged Weapons Listener
     */
    private final View.OnClickListener ButtonRangedListener = v -> {
        RangedWeaponsDataHandler rangedWeaponsDataHandler = new RangedWeaponsDataHandler(LooterActivity.this);
        TWeaponsRanged tWeaponsRanged = rangedWeaponsDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tWeaponsRanged.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Melee Weapons Listener
     */
    private final View.OnClickListener ButtonMeleeListener = v -> {
        MeleeWeaponsDataHandler meleeWeaponsDataHandler = new MeleeWeaponsDataHandler(LooterActivity.this);
        TWeaponsMelee tWeaponsMelee = meleeWeaponsDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tWeaponsMelee.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Explosives Listener
     */
    private final View.OnClickListener ButtonExplosivesListener = v -> {
        ThrownExplosivesWeaponsDataHandler thrownExplosivesWeaponsDataHandler = new ThrownExplosivesWeaponsDataHandler(LooterActivity.this);
        TWeaponsThrownExplosives tWeaponsThrownExplosives = thrownExplosivesWeaponsDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tWeaponsThrownExplosives.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Oddities Listener
     */
    private final View.OnClickListener ButtonOdditiesListener = v -> {
        OdditiesDataHandler odditiesDataHandler = new OdditiesDataHandler(LooterActivity.this);
        TOddities tOddities = odditiesDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tOddities.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Junk Listener
     */
    private final View.OnClickListener ButtonJunkListener = v -> {
        JunkDataHandler junkDataHandler = new JunkDataHandler(LooterActivity.this);
        TJunk tJunk = junkDataHandler.selectById( Dice.roll2D20());
        String text = resultTextView.getText().toString() + ", " + tJunk.getDrop();
        resultTextView.setText(text);
    };

    /**
     * Button Reset Listener
     */
    private final View.OnClickListener ButtonResetListener = v ->
            resultTextView.setText(addBareMinimumLoot());

    //------------------------------ dices ------------------------------//

    /**
     * Adds the bare minimum loot to the table. This loots consists in 1 roll in Clothing, 2 rolls
     * in Food, 1 roll in Beverages, 2 rolls in Junk. Results are automatically added to the table.
     *
     * @return Teh bare minimum
     */
    private String addBareMinimumLoot (){
        ClothingDataHandler clothingDataHandler = new ClothingDataHandler(LooterActivity.this);
        FoodDataHandler foodDataHandler = new FoodDataHandler(LooterActivity.this);
        BeveragesDataHandler beveragesDataHandler = new BeveragesDataHandler(LooterActivity.this);

        TClothing clothing = clothingDataHandler.selectById( Dice.roll2D20());
        TFood food1 = foodDataHandler.selectById ( Dice.roll2D20());
        TFood food2 = foodDataHandler.selectById ( Dice.roll2D20());
        TBeverages beverages = beveragesDataHandler.selectById ( Dice.roll2D20());

        return clothing.getDrop() +
                ", " + food1.getDrop() +
                ", " + food2.getDrop() +
                ", " + beverages.getDrop();
    }

}
