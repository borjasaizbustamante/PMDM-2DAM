package es.fallout.looter.database.handlers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import es.fallout.looter.database.tables.TGenericTwoColumnDrop;

/**
 * Generic Handler superclass for all tables with only two columns: Id + Drop
 */
public abstract class GenericIdDropDataHandler extends DataHandler {

    /**
     * Constructor
     *
     * @param context The context
     */
    protected GenericIdDropDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Drops the table
     *
     * @param tableName The table name
     */
    protected void drop (String tableName){
        Log.i ( GenericIdDropDataHandler.class.getName(), "drop " + tableName);
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase ();
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + tableName);
    }

    /**
     * Selects * from table
     *
     * @param tableName The table name
     * @return List<TGenericTwoColumnDrop>
     */
    protected List<TGenericTwoColumnDrop> selectAll ( String tableName) {
        Log.i ( GenericIdDropDataHandler.class.getName(), "select * from " + tableName);
        List<TGenericTwoColumnDrop> ret = new ArrayList<>();
        String query = "SELECT * FROM " + tableName;
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery(query, null);
        TGenericTwoColumnDrop tGenericTwoColumnDrop;
        while (cursor.moveToNext()) {
            tGenericTwoColumnDrop = new TGenericTwoColumnDrop();
            tGenericTwoColumnDrop.setId(cursor.getInt(0));
            tGenericTwoColumnDrop.setDrop(cursor.getString(1));
            ret.add(tGenericTwoColumnDrop);
        }
        cursor.close();
        sQLiteDatabase.close();
        return ret;
    }

    /**
     * Insert into table
     *
     * @param tGenericTwoColumnDrop The generic two column drop row
     * @param tableName The table name
     * @param col1Name The 1st column name
     * @param col2Name The 2nd column name
     */
    protected void insert (TGenericTwoColumnDrop tGenericTwoColumnDrop, String tableName, String col1Name, String col2Name) {
        Log.i ( GenericIdDropDataHandler.class.getName(), "insert " + tGenericTwoColumnDrop.getId() + " into " + tableName);
        ContentValues values = new ContentValues();
        values.put(col1Name, tGenericTwoColumnDrop.getId());
        values.put(col2Name, tGenericTwoColumnDrop.getDrop());

        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.insert(tableName, null, values);
        sQLiteDatabase.close();
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @param tableName The table name
     * @param col1Name The 1st column name
     * @return TGenericTwoColumnDrop
     */
    protected TGenericTwoColumnDrop selectById (int id, String tableName, String col1Name) {
        Log.i ( GenericIdDropDataHandler.class.getName(), "select * from " + tableName + " where id = " + id);
        String query = "Select * FROM " + tableName + " WHERE " + col1Name +
                " = " + "'" + id + "'";
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery(query, null);

        TGenericTwoColumnDrop tGenericTwoColumnDrop = new TGenericTwoColumnDrop ();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            tGenericTwoColumnDrop.setId(cursor.getInt(0));
            tGenericTwoColumnDrop.setDrop(cursor.getString(1));
            cursor.close();
        } else {
            tGenericTwoColumnDrop = null;
        }
        sQLiteDatabase.close();
        return tGenericTwoColumnDrop;
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @param tableName The table name
     * @param col1Name The 1st column name
     * @return int
     */
    protected int deleteById (int id, String tableName, String col1Name) {
        Log.i ( GenericIdDropDataHandler.class.getName(), "delete from " + tableName + " where Id = " + id);
        int ret;
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        TGenericTwoColumnDrop tGenericTwoColumnDrop = new TGenericTwoColumnDrop ();
        tGenericTwoColumnDrop.setId(id);
        ret = sQLiteDatabase.delete(tableName, col1Name + "=?",
                new String[] {
                        String.valueOf(tGenericTwoColumnDrop.getId())
                });
        sQLiteDatabase.close();
        return ret;
    }

    /**
     * Update table
     *
     * @param tGenericTwoColumnDrop The generic two column row
     * @param tableName The table name
     * @param col1Name The 1st column name
     * @param col2Name The 2nd column name
     * @return boolean
     */
    protected boolean update (TGenericTwoColumnDrop tGenericTwoColumnDrop, String tableName, String col1Name, String col2Name) {
        Log.i ( GenericIdDropDataHandler.class.getName(), "update " + tableName + " set ...");
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(col1Name, tGenericTwoColumnDrop.getId());
        args.put(col2Name, tGenericTwoColumnDrop.getDrop());
        String whereClause = col1Name + "=" + tGenericTwoColumnDrop.getId();
        return sQLiteDatabase.update(tableName, args, whereClause, null) > 0;
    }
}
