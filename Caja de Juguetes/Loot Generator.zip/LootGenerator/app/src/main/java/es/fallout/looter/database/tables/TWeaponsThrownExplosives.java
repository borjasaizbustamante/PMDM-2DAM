package es.fallout.looter.database.tables;

/**
 * Weapons (Thrown/Explosives) table
 */
public class TWeaponsThrownExplosives extends TGenericTwoColumnDrop{

    public TWeaponsThrownExplosives(){}

    public TWeaponsThrownExplosives(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
