package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.tables.TWeaponsMelee;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Ranged Weapons
 */
public class MeleeWeaponsDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TWeaponsMelee> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public MeleeWeaponsDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( GenericIdDropDataHandler.class.getName(), "populate " + TABLE_NAME_WEAPONS_MELEE);
        Log.i ( AmmoDataHandler.class.getName(), "populate " + TABLE_NAME_WEAPONS_MELEE);
        TWeaponsMelee tWeaponsRanged;
        for (int i = 2; i <= 40; i++){
            tWeaponsRanged = new TWeaponsMelee ();
            tWeaponsRanged.setId(i);
            tWeaponsRanged.setDrop(context.getString( Utils.getStringId(TABLE_NAME_WEAPONS_MELEE + "_C2_F" + i)));
            insert (tWeaponsRanged);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_WEAPONS_MELEE);
    }

    /**
     * Selects * from table
     *
     * @return List<TWeaponsRanged>
     */
    public List<TWeaponsMelee> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_WEAPONS_MELEE );
        return Utils.downcast (list, TWeaponsMelee::new);
    }

    /**
     * Insert into table
     *
     * @param tWeaponsMelee The row
     */
    public void insert(TWeaponsMelee tWeaponsMelee) {
        insert (tWeaponsMelee, TABLE_NAME_WEAPONS_MELEE, COLUMN_ID, COLUMN_WEAPONS_MELEE);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TWeaponsMelee
     */
    public TWeaponsMelee selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_WEAPONS_MELEE, COLUMN_ID);
        return new TWeaponsMelee(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_WEAPONS_MELEE, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tWeaponsMelee The row
     * @return boolean
     */
    public boolean update(TWeaponsMelee tWeaponsMelee) {
        return update (tWeaponsMelee, TABLE_NAME_WEAPONS_MELEE, COLUMN_ID, COLUMN_WEAPONS_MELEE);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_WEAPONS_MELEE);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_WEAPONS_MELEE);
    }
}
