package es.fallout.looter.database.tables;

/**
 * Table for a generic two-column table for drops
 */
public class TGenericTwoColumnDrop {

    private int id = 0;

    private String drop = null;

    public TGenericTwoColumnDrop(){}

    public TGenericTwoColumnDrop(int id, String drop) {
        this.id = id;
        this.drop = drop;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDrop() {
        return drop;
    }

    public void setDrop(String drop) {
        this.drop = drop;
    }
}
