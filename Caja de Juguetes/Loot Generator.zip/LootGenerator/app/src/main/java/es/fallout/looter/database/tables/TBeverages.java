package es.fallout.looter.database.tables;

/**
 * Beverages table
 */
public class TBeverages extends TGenericTwoColumnDrop{

    public TBeverages(){}

    public TBeverages(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
