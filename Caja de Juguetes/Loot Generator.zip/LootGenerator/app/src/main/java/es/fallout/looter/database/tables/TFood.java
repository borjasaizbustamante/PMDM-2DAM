package es.fallout.looter.database.tables;

/**
 * Food table
 */
public class TFood extends TGenericTwoColumnDrop{

    public TFood(){}

    public TFood(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
