package es.fallout.looter.database.handlers;

import android.content.Context;
import android.util.Log;

import java.util.List;

import es.fallout.looter.database.tables.TClothing;
import es.fallout.looter.database.tables.TGenericTwoColumnDrop;
import es.fallout.looter.database.utils.Utils;

/**
 * Data Base for Clothing
 */
public class ClothingDataHandler extends GenericIdDropDataHandler implements HandlerInterface <TClothing> {

    /**
     * Constructor
     *
     * @param context The context
     */
    public ClothingDataHandler(Context context) {
        super( context );
        this.context = context;
    }

    /**
     * Populates the table
     */
    public void populate (){
        Log.i ( GenericIdDropDataHandler.class.getName(), "populate " + TABLE_NAME_CLOTHING);
        Log.i ( AmmoDataHandler.class.getName(), "populate " + TABLE_NAME_CLOTHING);
        TClothing tClothing;
        for (int i = 2; i <= 40; i++){
            tClothing = new TClothing ();
            tClothing.setId(i);
            tClothing.setDrop(context.getString( Utils.getStringId(TABLE_NAME_CLOTHING + "_C2_F" + i)));
            insert (tClothing);
        }
    }

    /**
     * Drops the table
     */
    public void drop() {
        drop (TABLE_NAME_CLOTHING);
    }

    /**
     * Selects * from table
     *
     * @return List<TAmmo>
     */
    public List<TClothing> selectAll() {
        List<TGenericTwoColumnDrop> list = selectAll( TABLE_NAME_CLOTHING );
        return Utils.downcast (list, TClothing::new);
    }

    /**
     * Insert into table
     *
     * @param tClothing The row
     */
    public void insert(TClothing tClothing) {
        insert (tClothing, TABLE_NAME_CLOTHING, COLUMN_ID, COLUMN_CLOTHING);
    }

    /**
     * Select by Id
     *
     * @param id The id
     * @return TArmor
     */
    public TClothing selectById(int id) {
        TGenericTwoColumnDrop tGenericTwoColumnDrop = selectById (id, TABLE_NAME_CLOTHING, COLUMN_ID);
        return new TClothing(tGenericTwoColumnDrop);
    }

    /**
     * Delete from table
     *
     * @param id The id
     * @return int
     */
    public int deleteById(int id) {
        return deleteById(id, TABLE_NAME_CLOTHING, COLUMN_ID);
    }

    /**
     * Update table
     *
     * @param tClothing The row
     * @return boolean
     */
    public boolean update(TClothing tClothing) {
        return update (tClothing, TABLE_NAME_CLOTHING, COLUMN_ID, COLUMN_CLOTHING);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean ifTableExists() {
        return ifTableExists(TABLE_NAME_CLOTHING);
    }

    /**
     * Returns true if the table exists, false otherwise
     *
     * @return True or False
     */
    public boolean isEmpty() {
        return isEmpty(TABLE_NAME_CLOTHING);
    }
}
