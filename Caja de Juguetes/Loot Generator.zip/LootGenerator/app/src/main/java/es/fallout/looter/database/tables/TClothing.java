package es.fallout.looter.database.tables;

/**
 * Clothing table
 */
public class TClothing extends TGenericTwoColumnDrop{

    public TClothing(){}

    public TClothing(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
