package es.fallout.looter.database.tables;

/**
 * Chem table
 */
public class TChem extends TGenericTwoColumnDrop{

    public TChem(){}

    public TChem(TGenericTwoColumnDrop tGenericTwoColumnDrop){
        this.setId(tGenericTwoColumnDrop.getId());
        this.setDrop(tGenericTwoColumnDrop.getDrop());
    }
}
