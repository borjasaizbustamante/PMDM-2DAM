package com.example.animation;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

/**
 * This app uses: a gradient, a transition, an animated button
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // The activity_main layout includes in its android:background property
        // a gradient defined in res/drawable/degradable.xml

        Button button = (Button)findViewById(R.id.btn_Activity);
        ImageView imageView = (ImageView) findViewById(R.id.img_Robot);

        // Animation for the button: move in the X axis for N milliseconds
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(button,"translationX",-800,0);
        objectAnimator.setDuration(4000);

        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(objectAnimator);
        animatorSet.start();

        // The transition for the image
        imageView.setBackgroundResource(R.drawable.transition);
        AnimationDrawable animationDrawable = (AnimationDrawable)imageView.getBackground();

        // The button listener. Starts and stops the transition
        button.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(button.getText().toString().equalsIgnoreCase(getResources().getString(R.string.btn_stop))){
                    button.setText(R.string.btn_start);
                    animationDrawable.stop();
                } else {
                    button.setText(R.string.btn_stop);
                    animationDrawable.start();
                }
            }
        });
    }
}