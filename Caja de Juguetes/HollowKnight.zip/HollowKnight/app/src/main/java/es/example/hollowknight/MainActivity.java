package es.example.hollowknight;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        (findViewById(R.id.btn_start)).setOnClickListener( view -> {
            ImageView vesselKnight = findViewById(R.id.imageView);
            vesselKnight.setImageResource(R.drawable.runningvessel);
            AnimationDrawable runningVessel = (AnimationDrawable)vesselKnight.getDrawable();
            runningVessel.start();
        } );

        (findViewById(R.id.btn_stop )).setOnClickListener( view -> {
            ImageView vesselKnight = findViewById(R.id.imageView);
            vesselKnight.setImageResource(R.drawable.runningvessel);
            AnimationDrawable runningVessel = (AnimationDrawable)vesselKnight.getDrawable();
            runningVessel.stop();
        } );
    }
}