package es.reto.fragments.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import es.reto.fragments.R;

public class SecondFragment extends Fragment {

    private Context context;

    private SecondFragment (Context context){
        this.context = context;
    }

    public static SecondFragment newInstance( Context context) {
        SecondFragment secondFragment = new SecondFragment(context);
        return secondFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_second, container, false);

        // Here, you can do whatever you want related to your layout, even setting events.
        // Just remember this is only a PART from a bigger Activity...

        return view;
    }
}
