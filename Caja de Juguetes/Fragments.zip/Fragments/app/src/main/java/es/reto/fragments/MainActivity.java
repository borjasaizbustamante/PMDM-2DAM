package es.reto.fragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import es.reto.fragments.adapters.MainActivityPagerAdapter;

/**
 * Let's do some cool shit with Fragments... We are going to set
 * a three-tab layout. The user can swap from one tab to another.
 * This MAY BE a way to reduce the amount of visible buttons and
 * stuff on a screen.
 *
 * Tricky to set and handle...
 */
public class MainActivity extends AppCompatActivity {

    // Viewpager for the fragments
    private ViewPager2 viewPager2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        // The tab titles
        String[] titles = new String[]{
                getString(R.string.txt_tab_tab1),
                getString(R.string.txt_tab_tab2),
                getString(R.string.txt_tab_tab3)
        };

        // If you need to pass a variable to MainActivityPagerAdapter
        // you can add a getter & setter into it as normal
        viewPager2 = (ViewPager2) findViewById(R.id.viewPager2);
        MainActivityPagerAdapter mainActivityPagerAdapter = new MainActivityPagerAdapter(
                this,MainActivity.this);
        viewPager2.setAdapter(mainActivityPagerAdapter);

        // The layout that holds the fragments
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        new TabLayoutMediator(tabLayout, viewPager2,
                (tab, position) -> tab.setText(titles[position])).attach();
    }

    // If the user presses the 'back button' on his phone, we want to
    // 'go back' to the previous Tab
    @Override
    public void onBackPressed() {
        if (viewPager2.getCurrentItem() == 0) {
            super.onBackPressed();
        } else {
            viewPager2.setCurrentItem(viewPager2.getCurrentItem() - 1);
        }
    }
}