package es.reto.fragments.adapters;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import es.reto.fragments.fragments.FirstFragment;
import es.reto.fragments.fragments.SecondFragment;
import es.reto.fragments.fragments.ThirdFragment;

/**
 * The Adapter for the three tabs
 */
public class MainActivityPagerAdapter extends FragmentStateAdapter {

    private static final int NUM_PAGES = 3;
    private Context context;

    public MainActivityPagerAdapter(FragmentActivity fragmentActivity, Context context) {
        super(fragmentActivity);
        this.context = context;
    }

    // Our three tabs. You can also pass whatever variables you need to a Fragment
    // via getters & setters; or in the Constructor
    @Override
    public Fragment createFragment(int pos) {
        switch (pos) {
            case 0: return FirstFragment.newInstance(context);
            case 1: return SecondFragment.newInstance(context);
            case 2: return ThirdFragment.newInstance(context);
            default: return FirstFragment.newInstance(context);
        }
    }

    @Override
    public int getItemCount() {
        return NUM_PAGES;
    }
}
