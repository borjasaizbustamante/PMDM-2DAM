package com.example.spinwheel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        (findViewById(R.id.spinButton)).setOnClickListener(view -> {

            (findViewById(R.id.spinButton)).setEnabled(false);
            new CountDownTimer(((new Random().nextInt(20)+10) * 30)*20,1) {
                @Override
                public void onTick(long l) {
                    float rotation = (findViewById(R.id.wheelImage)).getRotation() - 2;
                    (findViewById(R.id.wheelImage)).setRotation(rotation <= -360? 0 : rotation);
                }

                @Override
                public void onFinish() {
                    (findViewById(R.id.spinButton)).setEnabled(true);
                    int finalRotation = (int) (findViewById(R.id.wheelImage)).getRotation();
                    Toast.makeText(MainActivity.this , "" + (int) Math.abs(Math.ceil(finalRotation/30 - 1 )), Toast.LENGTH_SHORT).show();
                }
            }.start();
        });
    }
}