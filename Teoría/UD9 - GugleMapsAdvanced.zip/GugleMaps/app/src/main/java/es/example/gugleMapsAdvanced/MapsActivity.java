package es.example.gugleMapsAdvanced;

import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleMap.OnMapClickListener {

    // The google map
    private GoogleMap googleMap;

    // The coordinates
    private static final double latitude = 39.481106;
    private static final double longitude = -0.340987;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView(R.layout.activity_maps);

        // Get the Map asynchronously. When ready, it will be notified
        // via onMapReady ()
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        findViewById( R.id.directToUniversity ).setOnClickListener( view ->
                googleMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(latitude, longitude))) );

        findViewById( R.id.slowlyToUniversity ).setOnClickListener( view ->
                googleMap.animateCamera(CameraUpdateFactory.newLatLng(new LatLng(latitude, longitude))) );

        findViewById( R.id.addMarker ).setOnClickListener( view ->
                googleMap.addMarker(new MarkerOptions().position(googleMap.getCameraPosition().target)) );
    }

    // Called when the map is READY to be used
    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        LatLng latLng = new LatLng(latitude, longitude);

        // The map is ready, lets prepare...
        googleMap = map;
        googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        googleMap.getUiSettings().setZoomControlsEnabled(false);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));

        // The map os ready, lets show a marker in the map...
        googleMap.addMarker(new MarkerOptions().position(latLng).title(getString(R.string.txt_my_marker)));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(getString(R.string.txt_my_marker))
                .snippet(getString(R.string.txt_my_snippet))
                .icon( BitmapDescriptorFactory
                        .fromResource(android.R.drawable.ic_menu_compass))
                .anchor(0.5f, 0.5f));
        // If somebody clicks on the map...
        googleMap.setOnMapClickListener(this);

        // If we have permits for FINE_LOCATION...
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setCompassEnabled(true);
        }
    }

    // Somebody does click on the map, we add a marker
    @Override
    public void onMapClick(@NonNull LatLng pointClicked) {
        googleMap.addMarker(new MarkerOptions().position(pointClicked)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
    }
}