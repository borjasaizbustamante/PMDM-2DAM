package es.pruebas.cooldatabase.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

import es.pruebas.cooldatabase.R;
import es.pruebas.cooldatabase.beans.Client;

/**
 * Adapter for the table...
 */
public class MyAdapter extends ArrayAdapter <Client> {

    private final List<Client> list;
    private final Context context;

    public MyAdapter(@NonNull Context context, int textViewResourceId, @NonNull List<Client> list) {
        super( context, textViewResourceId, list );
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount(){
        return super.getCount();
    }

    public View getView (int pos, View convertView, ViewGroup parent){
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate( R.layout.linea_layout, null );

        // Load each table line...
        ((TextView) view.findViewById( R.id.textViewNameLinea )).setText( list.get(pos).getName() );
        ((TextView) view.findViewById( R.id.textViewFirstNameLinea )).setText( list.get(pos).getFirstName() );
        ((TextView) view.findViewById( R.id.textViewLastNameLinea )).setText( list.get(pos).getLastName() );

        // PLEASE NOTE: you can add here whatever you want! Buttons, events, images....

        return view;
    }
}
