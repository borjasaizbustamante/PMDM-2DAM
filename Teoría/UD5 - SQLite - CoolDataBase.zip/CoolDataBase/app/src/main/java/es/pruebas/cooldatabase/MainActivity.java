package es.pruebas.cooldatabase;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import es.pruebas.cooldatabase.beans.Client;
import es.pruebas.cooldatabase.datamanager.DataManager;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        // We create and/or open a DataBase
        // First time, it launches onCreate
        DataManager dataManager = new DataManager(this);
        //dataManager.getWritableDatabase();

        // All EditText MUST be filled with something...
        (findViewById(R.id.buttonInsert)).setEnabled(false);
        ((EditText) findViewById( R.id.editTextName )).addTextChangedListener( registerEditTextListener );
        ((EditText) findViewById( R.id.editTextFirstName )).addTextChangedListener( registerEditTextListener );
        ((EditText) findViewById( R.id.editTextLastName )).addTextChangedListener( registerEditTextListener );

        (findViewById( R.id.buttonInsert)).setOnClickListener( v -> {
            // Insert!!
            String name = ((EditText) findViewById( R.id.editTextName )).getText().toString();
            String firstName = ((EditText) findViewById( R.id.editTextFirstName )).getText().toString();
            String lastName = ((EditText) findViewById( R.id.editTextLastName )).getText().toString();

            boolean found = false;
            if (!dataManager.isEmpty()){
                List<Client> clients = dataManager.selectAllClients();

                for (Client client : clients){
                    found = (client.getName().equals( name )) && (client.getFirstName().equals( firstName )) &&
                                    (client.getLastName().equals( lastName ));
                    if (found)
                        break;
                }
            }

            if (!found) {
                try {
                    Client cliente = new Client();
                    cliente.setName( name );
                    cliente.setFirstName( firstName );
                    cliente.setLastName( lastName );
                    dataManager.insert( cliente );

                    Toast.makeText(this, getString( R.string.cliente_insertado ), Toast.LENGTH_LONG).show();
                }catch (Exception e){
                    Toast.makeText(this, getString( R.string.error_DDBB ) + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, getString( R.string.cliente_existe ), Toast.LENGTH_LONG).show();
            }

        });

        (findViewById( R.id.buttonList)).setOnClickListener( v -> {
            startActivity(new Intent(getApplicationContext(), ListadoActivity.class));
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult( requestCode, resultCode, data );
        // Nothing to see here...
    }

    //------------------------- EditText Events -------------------------//

    /**
     * Disables the list button if editTexts are empty
     */
    private final TextWatcher registerEditTextListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            String name = ((EditText) findViewById( R.id.editTextName )).getText().toString();
            String firstName = ((EditText) findViewById( R.id.editTextFirstName )).getText().toString();
            String lastName = ((EditText) findViewById( R.id.editTextLastName )).getText().toString();

            (findViewById( R.id.buttonInsert )).setEnabled( !TextUtils.isEmpty( name ) && !TextUtils.isEmpty( firstName ) && !TextUtils.isEmpty( lastName ) );
        }
    };
}