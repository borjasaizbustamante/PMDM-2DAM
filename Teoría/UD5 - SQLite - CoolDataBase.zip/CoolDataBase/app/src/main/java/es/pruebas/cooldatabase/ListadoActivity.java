package es.pruebas.cooldatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import es.pruebas.cooldatabase.adapters.MyAdapter;
import es.pruebas.cooldatabase.beans.Client;
import es.pruebas.cooldatabase.datamanager.DataManager;

public class ListadoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_listado );

        // We create and/or open a DataBase
        // First time, it launches onCreate
        DataManager dataManager = new DataManager(this);
        List<Client> clients = dataManager.selectAllClients();

        if (null != clients) {
            MyAdapter myAdapter = new MyAdapter(this, R.id.listView, clients);
            ((ListView)findViewById(R.id.listView)).setAdapter( myAdapter );

        } else {
            Toast.makeText(this, getString( R.string.nothing_to_see ), Toast.LENGTH_LONG).show();
        }

        (findViewById( R.id.buttonCancelar)).setOnClickListener( v -> {
            finish();
        });
    }
}