package es.pruebas.cooldatabase.beans;

import java.io.Serializable;
import java.util.Objects;

/**
 * The Beans
 */
public class Client implements Serializable {

    private int id;
    private String name;
    private String firstName;
    private String lastName;

    public Client(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "Client{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Client)) return false;
        Client client = (Client) o;
        return getId() == client.getId() && getName().equals( client.getName() ) && getFirstName().equals( client.getFirstName() ) && getLastName().equals( client.getLastName() );
    }

    @Override
    public int hashCode() {
        return Objects.hash( getId(), getName(), getFirstName(), getLastName() );
    }
}
