package com.example.RestServerExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestServerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
