package com.example.RestServerExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestServerExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestServerExampleApplication.class, args);
	}

}
