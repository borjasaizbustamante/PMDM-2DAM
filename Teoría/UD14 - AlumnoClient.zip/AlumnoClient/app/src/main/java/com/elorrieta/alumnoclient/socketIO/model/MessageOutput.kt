package com.elorrieta.alumnoclient.socketIO.model

/**
 * The message sent when Login. The
 */
data class MessageOutput (private val message: String)