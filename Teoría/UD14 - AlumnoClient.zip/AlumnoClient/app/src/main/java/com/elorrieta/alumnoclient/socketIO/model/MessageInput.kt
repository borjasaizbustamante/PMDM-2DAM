package com.elorrieta.alumnoclient.socketIO.model

/**
 * The message sent when Login. The
 */
data class MessageInput (private val message: String)