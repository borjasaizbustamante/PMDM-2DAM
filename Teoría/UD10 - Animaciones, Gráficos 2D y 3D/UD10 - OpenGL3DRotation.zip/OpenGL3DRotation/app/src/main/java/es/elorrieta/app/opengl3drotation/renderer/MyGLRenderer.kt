import android.opengl.GLES20
import android.opengl.GLSurfaceView
import es.elorrieta.app.openglbasic.objects.Triangle
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import android.opengl.Matrix

class MyGLRenderer : GLSurfaceView.Renderer {

    // LET'S ADD SOME ROTATION

    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val rotationMatrix = FloatArray(16)

    private var angle = 0f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Background color: BLACK
        GLES20.glClearColor(0f, 0f, 0f, 1f)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)

        val ratio = width.toFloat() / height
        Matrix.frustumM(
            projectionMatrix,
            0,
            -ratio, ratio,
            -1f, 1f,
            3f, 7f
        )
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        // Camera
        Matrix.setLookAtM(
            viewMatrix, 0,
            0f, 0f, 5f,         // Eye
            0f, 0f, 0f,   // Center
            0f, 1f, 0f             // Up
        )

        // Rotation
        Matrix.setRotateM(rotationMatrix, 0, angle, 0f, 1f, 0f)

        // MVP = Projection * View * Model
        Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, rotationMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0)

        Triangle.draw(mvpMatrix)

        angle += 1f
    }

}
