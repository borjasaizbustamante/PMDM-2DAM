package es.elorrieta.app.opengl3drotation

import MyGLRenderer
import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var glView: GLSurfaceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // GL Surface
        glView = GLSurfaceView(this)

        // OpenGL ES 2.0
        glView.setEGLContextClientVersion(2)

        // The render
        glView.setRenderer(MyGLRenderer())

        // We do NOT need an activity_main.xml
        setContentView(glView)
    }
}