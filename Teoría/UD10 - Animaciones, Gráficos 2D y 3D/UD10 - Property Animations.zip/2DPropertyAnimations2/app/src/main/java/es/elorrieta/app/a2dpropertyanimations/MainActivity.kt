package es.elorrieta.app.a2dpropertyanimations

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // The component to animate
        // It can be almos anything, images, buttons, etc.

        val target = findViewById<View>(R.id.square)

        // Animate target when the button is pressed
        findViewById<Button>(R.id.btnStart).setOnClickListener {

            // What is gonna happen...
            val moveX = ObjectAnimator.ofFloat(target, "translationX", 0f, 300f)
            val scaleX = ObjectAnimator.ofFloat(target, "scaleX", 1f, 1.5f)
            val scaleY = ObjectAnimator.ofFloat(target, "scaleY", 1f, 1.5f)
            val rotate = ObjectAnimator.ofFloat(target, "rotation", 0f, 360f)

            AnimatorSet().apply {
                playTogether(moveX, scaleX, scaleY, rotate)
                duration = 1500 // duration of the animation in milliseconds
                start() // Starts the animation
            }
        }

        // Animate target when the same target is pressed
        target.setOnClickListener {
            val rotate = ObjectAnimator.ofFloat(target, "rotation", 0f, 360f)
            rotate.duration = 800

            // We can also control what happens at the beginning, the end, etc...
            rotate.addListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {
                    Log.i("ANIMATION", "onAnimationStart")
                }

                override fun onAnimationEnd(animation: Animator) {
                    Log.i("ANIMATION", "onAnimationEnd")
                }

                override fun onAnimationCancel(animation: Animator) {
                    Log.i("ANIMATION", "onAnimationCancel")
                }
                override fun onAnimationRepeat(animation: Animator) {
                    Log.i("ANIMATION", "onAnimationRepeat")
                }
            })
            rotate.start()
        }
    }
}