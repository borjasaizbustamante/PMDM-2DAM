package es.elorrieta.app.soundpoolbasic
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private lateinit var soundPool: SoundPool
    private var soundId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // SoundPool Configuration
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(5)       // Max. simultaneous Sounds
            .setAudioAttributes(audioAttributes)
            .build()

        // Load the Sound
        soundId = soundPool.load(this, R.raw.click_sound, 1)

        // The buttonn
        val btn = findViewById<Button>(R.id.btnPlay)
        btn.setOnClickListener {
            soundPool.play(
                soundId,
                1f,
                1f,
                1,
                0,
                1f
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundPool.release()  // liberar recursos
    }
}
