package es.elorrieta.app.a2dpropertyanimationsinterpolators

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.BounceInterpolator
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // The target
        val target = findViewById<View>(R.id.square)

        findViewById<Button>(R.id.btnAnimate).setOnClickListener {
            val anim = ObjectAnimator.ofFloat(target, "translationX", 0f, 500f)
            anim.duration = 1000

            // Interpolator for bouncing...
            anim.interpolator = BounceInterpolator()

            anim.start()
        }
    }
}