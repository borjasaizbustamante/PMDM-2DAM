package es.elorrieta.app.opengl3drotationfinger

import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import es.elorrieta.app.opengl3drotationfinger.renderer.MyGLRenderer
import android.view.MotionEvent

class MainActivity : AppCompatActivity() {

    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: MyGLRenderer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        renderer = MyGLRenderer()

        glView = object : GLSurfaceView(this) {
            private var previousX = 0f
            private var previousY = 0f

            // onTouchEvent must be declared here, not outside onCreate.
            // If not, due the fact renderer is a lateinit, it may happen
            // onTouchEvent() to be executed BEFORE renderer has a value;
            // or before the onCreate() has ended; or even before GLSurfaceView
            // is ready to use.
            override fun onTouchEvent(event: MotionEvent): Boolean {
                val x = event.x
                val y = event.y

                when (event.action) {
                    MotionEvent.ACTION_MOVE -> {
                        val dx = x - previousX
                        val dy = y - previousY

                        renderer.angleY += dx * 0.5f
                        renderer.angleX += dy * 0.5f
                    }
                }

                previousX = x
                previousY = y
                return true
            }
        }

        glView.setEGLContextClientVersion(2)
        glView.setRenderer(renderer)

        setContentView(glView)
    }
}