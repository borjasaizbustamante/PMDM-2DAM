package es.elorrieta.app.appretrofitclientexample.retrofit.entities

data class Alumno(
    val nombre: String,
    val apellido: String
)