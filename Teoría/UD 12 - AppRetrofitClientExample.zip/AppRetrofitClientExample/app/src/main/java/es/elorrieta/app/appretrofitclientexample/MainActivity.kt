package es.elorrieta.app.appretrofitclientexample

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import es.elorrieta.app.appretrofitclientexample.retrofit.adapters.AlumnoAdapter
import es.elorrieta.app.appretrofitclientexample.retrofit.client.RetrofitClient
import es.elorrieta.app.appretrofitclientexample.retrofit.entities.Alumno
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // The Api
        val api = RetrofitClient.alumnoInterface

        // Find All Button
        findViewById<Button>(R.id.listAllButton).setOnClickListener {

            // GET: Get all students. It is an Asynchronous call
            api.getAllAlumnos().enqueue(object : Callback<List<Alumno>> {

                // This triggers when the Server answers to our call
                override fun onResponse(
                    call: Call<List<Alumno>>,
                    response: Response<List<Alumno>>
                ) {
                    if (response.isSuccessful) {
                        // HTTP response code is 200
                        val alumnos = response.body()

                        if (alumnos.isNullOrEmpty()) {
                            Toast.makeText(
                                this@MainActivity,
                                "No hay datos que mostrar",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
                            recyclerView.layoutManager = LinearLayoutManager(this@MainActivity)
                            recyclerView.adapter = AlumnoAdapter(alumnos)
                        }
                    } else {
                        // HTTP response code is NOT 200. This usually means an error. But NOT ALWAYS!
                        Toast.makeText(
                            this@MainActivity,
                            "Error GET: ${response.code()}",
                            Toast.LENGTH_SHORT
                        ).show()
                        // Please, note that you MUST consider the HTTP response code individually!!
                    }
                }

                // This triggers when something went wrong. Usually, we couldn't even send the request
                override fun onFailure(call: Call<List<Alumno>>, t: Throwable) {
                    Toast.makeText(
                        this@MainActivity,
                        "Fallo de red: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }

        // New Student button
        findViewById<Button>(R.id.addNewStudentButton).setOnClickListener {

            // The new student
            var name = findViewById<EditText>(R.id.nameEditText).text.toString()
            var surname = findViewById<EditText>(R.id.surnameEditText).text.toString()

            // If no data is provided, we add "Ana Torres"
            // Do NOT do this outside this example
            name = name.ifEmpty { "Ana" }
            surname = surname.ifEmpty { "Torres" }

            val student = Alumno(name, surname)

            // POST: We add a new student. It is an Asynchronous call
            api.addAlumno(student).enqueue(object : Callback<Void> {

                // This triggers when the Server answers to our call
                override fun onResponse(call: Call<Void>, response: Response<Void>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@MainActivity, "Alumno insertado", Toast.LENGTH_SHORT)
                            .show()
                    }
                }

                // This triggers when something went wrong. Usually, we couldn't even send the request
                override fun onFailure(call: Call<Void>, t: Throwable) {
                    Toast.makeText(
                        this@MainActivity,
                        "Fallo POST: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }

        // Find the Student by name
        findViewById<Button>(R.id.find).setOnClickListener {

            val name = findViewById<EditText>(R.id.nameEditText).text.toString()

            // GET: get by name. It is an Asynchronous call
            api.getByName(name).enqueue(object : Callback<Alumno> {

                // This triggers when the Server answers to our call
                override fun onResponse(
                    call: Call<Alumno>,
                    response: Response<Alumno>
                ) {
                    if (response.isSuccessful) {
                        // HTTP response code is 200
                        val alumno = response.body()

                        if (alumno == null) {
                            Toast.makeText(
                                this@MainActivity,
                                "No hay datos que mostrar",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            val nameEdT = findViewById<EditText>(R.id.nameEditText)
                            nameEdT.text.clear()
                            nameEdT.text.append(alumno.nombre)
                            val surnameEdT = findViewById<EditText>(R.id.surnameEditText)
                            surnameEdT.text.clear()
                            surnameEdT.text.append(alumno.apellido)
                        }
                    } else if (response.code() == 404) {
                        // HTTP response code is 404, Student not found (check the server side
                        // for more insight
                        Toast.makeText(
                            this@MainActivity,
                            "Student not found",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        // HTTP response code is NOT 200 or 404. This usually means an error. But NOT ALWAYS!
                        Toast.makeText(
                            this@MainActivity,
                            "Error GET: ${response.code()}",
                            Toast.LENGTH_SHORT
                        ).show()
                        // Please, note that you MUST consider the HTTP response code individually!!
                    }
                }

                // This triggers when something went wrong. Usually, we couldn't even send the request
                override fun onFailure(call: Call<Alumno>, t: Throwable) {
                    Toast.makeText(
                        this@MainActivity,
                        "Fallo de red: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }
}