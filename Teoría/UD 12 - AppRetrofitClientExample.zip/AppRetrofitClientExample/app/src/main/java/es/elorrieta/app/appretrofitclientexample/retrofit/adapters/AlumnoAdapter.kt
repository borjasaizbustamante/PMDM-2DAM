package es.elorrieta.app.appretrofitclientexample.retrofit.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import es.elorrieta.app.appretrofitclientexample.R
import es.elorrieta.app.appretrofitclientexample.retrofit.entities.Alumno

class AlumnoAdapter(private val lista: List<Alumno>) :
    RecyclerView.Adapter<AlumnoAdapter.AlumnoViewHolder>() {

    inner class AlumnoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nombre: TextView = itemView.findViewById(R.id.textViewName)
        val apellido: TextView = itemView.findViewById(R.id.textViewSurname)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlumnoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_line, parent, false)
        return AlumnoViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlumnoViewHolder, position: Int) {
        val alumno = lista[position]
        holder.nombre.text = alumno.nombre
        holder.apellido.text = alumno.apellido
    }

    override fun getItemCount(): Int = lista.size
}
