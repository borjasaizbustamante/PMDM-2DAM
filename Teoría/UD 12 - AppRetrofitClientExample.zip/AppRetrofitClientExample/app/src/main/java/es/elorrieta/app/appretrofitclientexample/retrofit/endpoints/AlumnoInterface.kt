package es.elorrieta.app.appretrofitclientexample.retrofit.endpoints

import es.elorrieta.app.appretrofitclientexample.retrofit.entities.Alumno
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface AlumnoInterface {

    @GET("/alumnos")
    fun getAllAlumnos(): Call<List<Alumno>>

    @GET("/alumno/find/{name}")
    fun getByName(@Path("name") name: String): Call<Alumno>

    @POST("/alumno/new")
    fun addAlumno(@Body alumno: Alumno): Call<Void>
}
