package es.elorrieta.app.appretrofitclientexample.retrofit.client

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import es.elorrieta.app.appretrofitclientexample.retrofit.endpoints.AlumnoInterface

object RetrofitClient {
    private val retrofit = Retrofit.Builder()
        .baseUrl("http://10.0.2.2:8080") // localhost from the Android emulator
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val alumnoInterface: AlumnoInterface = retrofit.create(AlumnoInterface::class.java)
}
