package es.example.geoloc.pojo;

import androidx.annotation.NonNull;

import java.util.Objects;

/**
 * Not actually needed...
 */
public class Provider {

    public static final String[] ACCURACY = { "n/d", "precise", "imprecise" };
    public static final String[] POWER = { "n/d", "low", "middle","high" };
    public static final String[] STATUS = {"Out of service", "temporarily unavailable", "available"};

    private String name = null;
    private String accuracy = null;
    private String powerRequirement = null;
    private boolean isProviderEnabled = false;
    private boolean hasMonetaryCost = false;
    private boolean requiresCell = false;
    private boolean requiresNetwork = false;
    private boolean requiresSatellite = false;
    private boolean supportsAltitude = false;
    private boolean supportsBearing = false;
    private boolean supportsSpeed = false;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(String accuracy) {
        this.accuracy = accuracy;
    }

    public String getPowerRequirement() {
        return powerRequirement;
    }

    public void setPowerRequirement(String powerRequirement) {
        this.powerRequirement = powerRequirement;
    }

    public boolean isProviderEnabled() {
        return isProviderEnabled;
    }

    public void setProviderEnabled(boolean providerEnabled) {
        isProviderEnabled = providerEnabled;
    }

    public boolean isHasMonetaryCost() {
        return hasMonetaryCost;
    }

    public void setHasMonetaryCost(boolean hasMonetaryCost) {
        this.hasMonetaryCost = hasMonetaryCost;
    }

    public boolean isRequiresCell() {
        return requiresCell;
    }

    public void setRequiresCell(boolean requiresCell) {
        this.requiresCell = requiresCell;
    }

    public boolean isRequiresNetwork() {
        return requiresNetwork;
    }

    public void setRequiresNetwork(boolean requiresNetwork) {
        this.requiresNetwork = requiresNetwork;
    }

    public boolean isRequiresSatellite() {
        return requiresSatellite;
    }

    public void setRequiresSatellite(boolean requiresSatellite) {
        this.requiresSatellite = requiresSatellite;
    }

    public boolean isSupportsAltitude() {
        return supportsAltitude;
    }

    public void setSupportsAltitude(boolean supportsAltitude) {
        this.supportsAltitude = supportsAltitude;
    }

    public boolean isSupportsBearing() {
        return supportsBearing;
    }

    public void setSupportsBearing(boolean supportsBearing) {
        this.supportsBearing = supportsBearing;
    }

    public boolean isSupportsSpeed() {
        return supportsSpeed;
    }

    public void setSupportsSpeed(boolean supportsSpeed) {
        this.supportsSpeed = supportsSpeed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Provider)) return false;
        Provider that = (Provider) o;
        return isProviderEnabled() == that.isProviderEnabled() &&
                isHasMonetaryCost() == that.isHasMonetaryCost() &&
                isRequiresCell() == that.isRequiresCell() &&
                isRequiresNetwork() == that.isRequiresNetwork() &&
                isRequiresSatellite() == that.isRequiresSatellite() &&
                isSupportsAltitude() == that.isSupportsAltitude() &&
                isSupportsBearing() == that.isSupportsBearing() &&
                isSupportsSpeed() == that.isSupportsSpeed() &&
                Objects.equals( getName(), that.getName() ) &&
                Objects.equals( getAccuracy(), that.getAccuracy() ) &&
                Objects.equals( getPowerRequirement(), that.getPowerRequirement() );
    }

    @Override
    public int hashCode() {
        return Objects.hash( getName(), getAccuracy(), getPowerRequirement(),
                isProviderEnabled(), isHasMonetaryCost(), isRequiresCell(),
                isRequiresNetwork(), isRequiresSatellite(), isSupportsAltitude(),
                isSupportsBearing(), isSupportsSpeed() );
    }

    @NonNull
    @Override
    public String toString() {
        return "LocationProvider{" +
                "name='" + name + '\'' +
                ", accuracy='" + accuracy + '\'' +
                ", powerRequirement='" + powerRequirement + '\'' +
                ", isProviderEnabled=" + isProviderEnabled +
                ", hasMonetaryCost=" + hasMonetaryCost +
                ", requiresCell=" + requiresCell +
                ", requiresNetwork=" + requiresNetwork +
                ", requiresSatellite=" + requiresSatellite +
                ", supportsAltitude=" + supportsAltitude +
                ", supportsBearing=" + supportsBearing +
                ", supportsSpeed=" + supportsSpeed +
                '}';
    }
}
