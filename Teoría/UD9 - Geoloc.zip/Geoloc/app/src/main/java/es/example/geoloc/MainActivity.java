package es.example.geoloc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import es.example.geoloc.pojo.Provider;

/**
 * This example asks for all Location Providers (I.E. GPS) and list them.
 * Then, it chooses the best one, and shows my current location
 *
 * This App only shows text
 *
 * EMULATION: If you want to change your coordinates in the emulated android
 * devide, press the three points (Mode) and choose Location. From here you can
 * set new coordinates to the emulated device, making it think it is actually
 * wherever you want. Use the button LOAD GPX / KML to add the corresponding file.
 *
 * A GPX or KML file registers a temporal location sequence. Many programs like
 * Google Earth can generate those files. Use them to simulate your device position.
 */
public class MainActivity extends AppCompatActivity implements LocationListener {

    private static final int ACCESS_FINE_LOCATION_CODE = 100;
    private static final int ACCESS_COARSE_LOCATION_CODE = 200;

    // 10 Seconds
    private static final long TIME_MIN = 10 * 1000;

    // 5 meters
    private static final long DISTANCE_MIN = 5;

    // The Location Manager
    private LocationManager locationManager;

    // The chosen provider for our App
    private String chosenProvider = null;

    //-- Activity Lifecycle Shenanigans --//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        // The Location Manager
        locationManager = (LocationManager) getSystemService( LOCATION_SERVICE );

        // We created our own Provider to hold all data
        // Pretty unnecessary actually...
        List<Provider> allProviders = getAllProviders( locationManager );

        // We list all Providers
        ((TextView) findViewById( R.id.textView )).append(
            getText( R.string.txt_location_prov ).toString() + "\n\n" );
        for (Provider provider : allProviders) {
            ((TextView)findViewById( R.id.textView )).append(provider.toString() + "\n");
        }

        // Ok, let's the Location Manager search for the best provider
        // The criteria for the service provider
        Criteria criteria = new Criteria();
        criteria.setCostAllowed( false ); // We do not want to pay money!
        criteria.setAltitudeRequired( false );
        criteria.setAccuracy( Criteria.ACCURACY_FINE );

        // Best provider under our criteria
        chosenProvider = locationManager.getBestProvider( criteria, true );

        // We check if the permissions have been granted...
        if (ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED) {
            // Not granted... ask for it
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[] { Manifest.permission.ACCESS_FINE_LOCATION },
                    ACCESS_FINE_LOCATION_CODE);
        }

        if (ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED){
            // Not granted... ask for it
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[] { Manifest.permission.ACCESS_FINE_LOCATION },
                    ACCESS_COARSE_LOCATION_CODE);
        }

        // Let check chosen provider last location...
        ((TextView) findViewById( R.id.textView )).append("\n\n" +
                getText( R.string.txt_chosen_provider_last_location ).toString() + "\n\n" );

        // Android remembers the last location given by the providers...
        Location myLocation = locationManager.getLastKnownLocation( chosenProvider );
        ((TextView)findViewById( R.id.textView )).append(
                null == myLocation? (getText( R.string.txt_unknown_Location).toString()):
                        myLocation.toString() + "\n\n");
    }

    // Activity Lifecycle - We request for location Updates
    @Override
    protected void onResume() {
        super.onResume();
        // We check if the permissions have been granted...
        if (ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED) {
            // Not granted... ask for it
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[] { Manifest.permission.ACCESS_FINE_LOCATION },
                    ACCESS_FINE_LOCATION_CODE);
        }

        if (ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED){
            // Not granted... ask for it
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[] { Manifest.permission.ACCESS_FINE_LOCATION },
                    ACCESS_COARSE_LOCATION_CODE);
        }
        locationManager.requestLocationUpdates( chosenProvider, TIME_MIN, DISTANCE_MIN,this );
    }

    // Activity Lifecycle - We remove the Updates
    @Override
    protected void onPause() {
        super.onPause();
        locationManager.removeUpdates(this);
    }

    //-- Things that may happen to the Provider --//

    @Override
    public void onProviderDisabled(String provider) {
        ((TextView)findViewById( R.id.textView )).append(
                getText( R.string.txt_disabled_prov).toString() + provider + "\n");
    }

    @Override public void onProviderEnabled(String provider) {
        ((TextView)findViewById( R.id.textView )).append(
                getText( R.string.txt_enabled_prov).toString() + provider + "\n");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        ((TextView)findViewById( R.id.textView )).append( provider + " " +
                getText( R.string.txt_prov_status_change).toString() +
                Provider.STATUS[Math.max(0, status)] + ". " +
                getText( R.string.txt_extras).toString() + extras + "\n");
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        ((TextView)findViewById( R.id.textView )).append(location.toString() );
    }

    //-- Things that may happen to the Provider --//

    // Get ALl providers data formatted for our app
    private List<Provider> getAllProviders(LocationManager locationManager){
        List<Provider> ret = null;

        List<String> providerNames = locationManager.getAllProviders();
        if ((null != providerNames) && (providerNames.size() > 0))
            ret = new ArrayList<>();

        if (providerNames != null) {
            for (String providerName : providerNames) {
                Provider provider = new Provider();
                provider.setName(providerName);
                provider.setProviderEnabled(locationManager.isProviderEnabled( providerName ));
                provider.setAccuracy(Provider.ACCURACY[Math.max( 0, (locationManager.getProvider( providerName )).getAccuracy() )]);
                provider.setPowerRequirement(Provider.POWER[Math.max( 0, (locationManager.getProvider( providerName )).getPowerRequirement() )]);
                provider.setHasMonetaryCost((locationManager.getProvider( providerName )).hasMonetaryCost());
                provider.setRequiresCell((locationManager.getProvider( providerName )).requiresCell());
                provider.setRequiresNetwork((locationManager.getProvider( providerName )).requiresNetwork());
                provider.setRequiresSatellite((locationManager.getProvider( providerName )).requiresSatellite());
                provider.setSupportsAltitude((locationManager.getProvider( providerName )).supportsAltitude());
                provider.setSupportsBearing((locationManager.getProvider( providerName )).supportsBearing());
                provider.setSupportsSpeed((locationManager.getProvider( providerName )).supportsSpeed());
                ret.add( provider );
            }
        }
        return ret;
    }
}