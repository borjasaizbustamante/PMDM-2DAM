package es.elorrieta.app.roomempresas.room.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * An Entity/table
 */
@Entity(tableName = "t_enterprises")
data class Enterprise(
    @PrimaryKey (autoGenerate = true)
    var id: Long = 0,
    var nombre: String,
    var localizacion: String
)
