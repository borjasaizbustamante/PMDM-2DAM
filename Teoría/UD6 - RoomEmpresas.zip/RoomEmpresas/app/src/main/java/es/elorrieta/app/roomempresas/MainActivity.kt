package es.elorrieta.app.roomempresas

import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import es.elorrieta.app.roomempresas.adapter.EnterprisesAdapter
import es.elorrieta.app.roomempresas.room.MyRoomDatabase
import es.elorrieta.app.roomempresas.room.entities.Enterprise
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // -----------------------
        // The ROOM database does not exist when you installs de APP in the mobile
        // It is technically created when you access it for the first time. Also,
        // it is empty. So we preload it with some random data...

        // The sole instance of db
        val db = MyRoomDatabase(this)

        // We launch this part as a Coroutine. This means, a thread parallel to the Activity.
        // More or less. If we do like this, we can then update the UI easily, and this thread
        // dies whenever the Activity also dies
        lifecycleScope.launch(Dispatchers.IO) {
            // We get the EnterpriseDao and then call to getAll method
            val list = db.getEnterpriseDao().getAll()
            if (list.isEmpty()) {

                // Empty, so we add a few...
                db.getEnterpriseDao().insertAll(
                    Enterprise(nombre = "Elorrieta Inc.", localizacion = "Education"),
                    Enterprise(nombre = "TechNova", localizacion = "Software")
                )
            }
        }

        // -----------------------

        // The RecyclerView
        val enterprisesRecyclerView: RecyclerView = findViewById(R.id.enterprisesRecyclerView)
        enterprisesRecyclerView.layoutManager = LinearLayoutManager(this)

        // We load an empty list to the RecyclerView
        val enterprisesAdapter = EnterprisesAdapter(mutableListOf(), this)
        enterprisesRecyclerView.adapter = enterprisesAdapter

        // The Find All Button
        findViewById<Button>(R.id.buttonFindAllEnterprises).setOnClickListener {

            // The sole instance of db
            val db = MyRoomDatabase(this)

            // We launch this part as a Coroutine. This means, a thread parallel to the Activity.
            // More or less. If we do like this, we can then update the UI easily, and this thread
            // dies whenever the Activity also dies
            lifecycleScope.launch(Dispatchers.IO) {
                // We get the EnterpriseDao and then call to getAll method
                val list = db.getEnterpriseDao().getAll()

                // We do a Mutable List
                val enterpriseList = list.toMutableList()

                // Again, Coroutine stuff. This way, we can update the adapter
                launch(Dispatchers.Main) {
                    // We update the adapter
                    enterprisesAdapter.update(enterpriseList)
                }
            }
        }

        // -----------------------

        // The Add Button
        findViewById<Button>(R.id.buttonAddEnterprise).setOnClickListener {

            // The sole instance of db
            val db = MyRoomDatabase(this)

            // We launch this part as a Coroutine. This means, a thread parallel to the Activity.
            // More or less. If we do like this, we can then update the UI easily, and this thread
            // dies whenever the Activity also dies
            lifecycleScope.launch(Dispatchers.IO) {

                // We add a few more...
                db.getEnterpriseDao().insertAll(
                    Enterprise(nombre = "Bilbaotech", localizacion = "Software"),
                    Enterprise(nombre = "New Horizon", localizacion = "Videogames")
                )

                // Let's update the adapter...
                val list = db.getEnterpriseDao().getAll()

                // We do a Mutable List
                val enterpriseList = list.toMutableList()

                // Again, Coroutine stuff. This way, we can update the adapter
                launch(Dispatchers.Main) {
                    // We update the adapter
                    enterprisesAdapter.update(enterpriseList)
                }
            }
        }

        // -----------------------

        // The delete Button
        findViewById<Button>(R.id.buttonDeleteEnterprise).setOnClickListener {

            // The sole instance of db
            val db = MyRoomDatabase(this)

            // We launch this part as a Coroutine. This means, a thread parallel to the Activity.
            // More or less. If we do like this, we can then update the UI easily, and this thread
            // dies whenever the Activity also dies
            lifecycleScope.launch(Dispatchers.IO) {

                // We need the ID for deletion, we find the enterprise first
                val listToDelete = db.getEnterpriseDao().getAll()
                val enterpriseToDelete = listToDelete.firstOrNull  { it.nombre == "Bilbaotech" }
                if (null != enterpriseToDelete) {
                    db.getEnterpriseDao().delete(enterpriseToDelete)

                    // Let's update the adapter...
                    val list = db.getEnterpriseDao().getAll()

                    // We do a Mutable List
                    val enterpriseList = list.toMutableList()

                    // Again, Coroutine stuff. This way, we can update the adapter
                    launch(Dispatchers.Main) {
                        // We update the adapter
                        enterprisesAdapter.update(enterpriseList)
                    }
                }
            }
        }

        // The delete by name Button
        findViewById<Button>(R.id.buttonDeleteByNameEnterprise).setOnClickListener {

            // The sole instance of db
            val db = MyRoomDatabase(this)

            // We launch this part as a Coroutine. This means, a thread parallel to the Activity.
            // More or less. If we do like this, we can then update the UI easily, and this thread
            // dies whenever the Activity also dies
            lifecycleScope.launch(Dispatchers.IO) {

                // We delete one by name...
                db.getEnterpriseDao().deleteByName("New Horizon")

                // Let's update the adapter...
                val list = db.getEnterpriseDao().getAll()

                // We do a Mutable List
                val enterpriseList = list.toMutableList()

                // Again, Coroutine stuff. This way, we can update the adapter
                launch(Dispatchers.Main) {
                    // We update the adapter
                    enterprisesAdapter.update(enterpriseList)
                }
            }
        }
    }
}