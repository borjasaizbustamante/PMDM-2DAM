package es.elorrieta.app.roomempresas.room.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import es.elorrieta.app.roomempresas.room.entities.Enterprise

// One DAO for each entity/table
@Dao
interface EnterpriseDao {

    // Put here all the methods you want to

    @Query ("select * from t_enterprises order by id")
    fun getAll () : List <Enterprise>

    @Insert
    fun insertAll(vararg enterprises: Enterprise)

    @Delete
    fun delete(enterprise: Enterprise)

    @Query ("delete from t_enterprises where nombre = :name")
    fun deleteByName(name: String)
}