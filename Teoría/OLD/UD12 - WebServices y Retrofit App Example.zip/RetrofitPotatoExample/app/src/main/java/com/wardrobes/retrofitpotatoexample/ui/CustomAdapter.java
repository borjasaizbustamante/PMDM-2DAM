package com.wardrobes.retrofitpotatoexample.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wardrobes.retrofitpotatoexample.R;
import com.wardrobes.retrofitpotatoexample.retrofit.entities.Potato;

import java.util.List;

/**
 * Custom adapter for the recycler view
 */
public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

    private final List<Potato> potatoes;

    public CustomAdapter(List<Potato> potatoes){
        this.potatoes = potatoes;
    }

    public static class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View myView;

        private final TextView textId;
        private final TextView textName;
        private final TextView textAmount;

        CustomViewHolder(View itemView) {
            super(itemView);
            myView = itemView;

            textId = myView.findViewById(R.id.textViewId);
            textName = myView.findViewById(R.id.textViewName);
            textAmount = myView.findViewById(R.id.textViewAmout);
        }
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_line, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.textId.setText(potatoes.get(position).getId() + "");
        holder.textName.setText(potatoes.get(position).getName());
        holder.textAmount.setText(potatoes.get(position).getAmount() + "");
    }

    @Override
    public int getItemCount() {
        return potatoes.size();
    }
}
