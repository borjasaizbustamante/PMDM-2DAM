package com.wardrobes.retrofitpotatoexample;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wardrobes.retrofitpotatoexample.retrofit.entities.Potato;
import com.wardrobes.retrofitpotatoexample.retrofit.endpoints.PotatoesInterface;
import com.wardrobes.retrofitpotatoexample.retrofit.instances.PotatoInstance;
import com.wardrobes.retrofitpotatoexample.ui.CustomAdapter;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private PotatoesInterface service = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // The service
        service = null == service?
                PotatoInstance.getRetrofitInstance().create(PotatoesInterface.class) :
                service;

        // The 'All' button
        findViewById(R.id.listAllButton).setOnClickListener(v -> {

            Call<List<Potato>> call = service.getAllPotatoes();
            call.enqueue(new Callback<List<Potato>>() {

                @Override
                public void onResponse(@NonNull Call<List<Potato>> call, @NonNull Response<List<Potato>> response) {

                    // Get the potatoes
                    List<Potato> potatoes = response.body();

                    // Let the adapter do the magic and display the potatoes
                    RecyclerView recyclerView = findViewById(R.id.recyclerView);
                    CustomAdapter adapter = new CustomAdapter(potatoes);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
                    recyclerView.setLayoutManager(layoutManager);
                    recyclerView.setAdapter(adapter);
                }

                @Override
                public void onFailure(@NonNull Call<List<Potato>> call, @NonNull Throwable t) {
                    Toast.makeText(MainActivity.this, "Something went wrong...", Toast.LENGTH_SHORT).show();
                }
            });
        });

        // The 'All' button
        findViewById(R.id.addPNewPotatoButton).setOnClickListener(v -> {

            Potato potato = new Potato(Integer.parseInt(((EditText)findViewById(R.id.idEditText)).getText().toString()),
                    ((EditText)findViewById(R.id.nameEditText)).getText().toString(),
                    (Integer.parseInt(((EditText)findViewById(R.id.amountEditText)).getText().toString())));

            Call <Void> call = service.addPNewPotato(potato);
            call.enqueue(new Callback <Void> () {

                @Override
                public void onResponse(@NonNull Call <Void> call, @NonNull Response <Void> response) {
                    Toast.makeText(MainActivity.this, "Done!", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailure(@NonNull Call <Void> call, @NonNull Throwable t) {
                    Toast.makeText(MainActivity.this, "Something went wrong...", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }
}