package com.wardrobes.retrofitpotatoexample.retrofit.endpoints;

import com.wardrobes.retrofitpotatoexample.retrofit.entities.Potato;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface PotatoesInterface {

    @GET("/potato/getAll")
    Call<List<Potato>> getAllPotatoes();

    @POST("/potato/addNewP/")
    Call <Void> addPNewPotato(@Body Potato potato);
}
