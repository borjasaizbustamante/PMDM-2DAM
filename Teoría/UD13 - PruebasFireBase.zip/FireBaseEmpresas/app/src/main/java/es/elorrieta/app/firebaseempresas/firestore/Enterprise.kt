package es.elorrieta.app.firebaseempresas.firestore

// Los valores por defecto (= "", = 0) son necesarios porque Firestore
// necesita un constructor vacío para deserializar.
data class Enterprise(var id: String = "",
                      var nombre: String = "",
                      var localizacion: String = "")
