package es.elorrieta.app.firebaseempresas

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import es.elorrieta.app.firebaseempresas.adapter.EnterprisesAdapter
import es.elorrieta.app.firebaseempresas.firestore.Enterprise


class MainActivity : AppCompatActivity() {

    // Firestore Instance
    private val db = FirebaseFirestore.getInstance()

    // On Create
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // The RecyclerView
        val enterprisesRecyclerView: RecyclerView = findViewById(R.id.enterprisesRecyclerView)
        enterprisesRecyclerView.layoutManager = LinearLayoutManager(this)

        // We load an empty list to the RecyclerView
        val enterprisesAdapter = EnterprisesAdapter(mutableListOf(), this)
        enterprisesRecyclerView.adapter = enterprisesAdapter

        // The Find All Button
        findViewById<Button>(R.id.buttonFindAllEnterprises).setOnClickListener {
            // A Mutable List in Kotlin is a list whose contents can be changed after it is created
            val enterpriseList = mutableListOf<Enterprise>()

            // Access to DB to retrieve "EmpresaBD" Documents. Note there are TWO possible events
            // for the call: OnSuccess y OnFailure. We must provide behaviour for both
            db.collection("EmpresaBD")
                .get()
                .addOnSuccessListener { result ->
                    // So, everything went OK. This DOES NOT MEAN we found any Documents
                    // We loop and retrieve each Document individually
                    // NOTE the Document ID must be assigned manually
                    for (document in result) {
                        val enterprise = document.toObject(Enterprise::class.java)
                        enterprise.id = document.id // The ID must be assigned manually
                        enterpriseList.add(enterprise)
                        Log.d("Firestore", "Enterprise: $enterprise")
                    }
                    // We update the adapter
                    enterprisesAdapter.update(enterpriseList)
                }
                .addOnFailureListener { exception ->

                    // Something went wrong. This DOES NOT MEAN there were no Documents. This means
                    // something serious, like server errors, etc.
                    Toast.makeText(
                        this,
                        "Error when reading enterprises - $exception",
                        Toast.LENGTH_SHORT
                    ).show()
                    Log.e("Firestore", "Error when reading enterprises", exception)
                }
        }
    }
}