package es.elorrieta.app.firebaseempresas.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import es.elorrieta.app.firebaseempresas.R
import es.elorrieta.app.firebaseempresas.firestore.Enterprise

/**
 * The Adapter for the Enterprises list. Requires
 */
class EnterprisesAdapter(private var enterprises: MutableList<Enterprise>,
                         private val context: Context) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val TYPE_HEADER = 0
    private val TYPE_ITEM = 1

    // ViewHolder for Enterprises
    class EnterpriseViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val id: TextView = view.findViewById(R.id.TextViewId)
        val name: TextView = view.findViewById(R.id.TextViewName)
        val localization: TextView = view.findViewById(R.id.TextViewLocalization)
    }

    // ViewHolder for header
    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val id: TextView = view.findViewById(R.id.TextViewId)
        val name: TextView = view.findViewById(R.id.TextViewName)
        val localization: TextView = view.findViewById(R.id.TextViewLocalization)
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) TYPE_HEADER else TYPE_ITEM
    }

    // Called when RecyclerView needs a new RecyclerView (A Header or a Normal Row)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder{

        val layout = if (viewType == TYPE_HEADER)
            R.layout.item_empresa_header   // 👈 usa otro layout para el header
        else
            R.layout.item_empresa

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_empresa, parent, false)

        return if (viewType == TYPE_HEADER) HeaderViewHolder(view)
        else EnterpriseViewHolder(view)
    }

    // Displays the data on an specific position
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        Log.d("Adapter", "onBindViewHolder position=$position, type=${getItemViewType(position)}")

        if (holder is HeaderViewHolder) {
            holder.id.text = context.getString(R.string.ID)
            holder.name.text = context.getString(R.string.Name)
            holder.localization.text = context.getString(R.string.Localization)
        } else if (holder is EnterpriseViewHolder) {
            val enterprise = enterprises[position - 1]
            Log.d("Adapter", "Binding enterprise: ${enterprise.nombre}")
            holder.id.text = enterprise.id
            holder.name.text = enterprise.nombre
            holder.localization.text = enterprise.localizacion
        }
    }

    // Returns the total number of items in the data set held by the adapter (+1 for header)
    override fun getItemCount(): Int {
        val count = enterprises.size + 1
        Log.d("Adapter", "getItemCount = $count")
        return count
    }

    // Refresh the Enterprises list
    fun update(newEnterprises: MutableList<Enterprise>) {
        Log.d("Adapter", "Updating adapter with ${newEnterprises.size} enterprises")
        enterprises = newEnterprises
        notifyDataSetChanged()
    }
}
