plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)

    // Add the Google services Gradle plugin
    id("com.google.gms.google-services")
}

android {
    namespace = "es.elorrieta.app.firebaseempresas"
    compileSdk = 36

    defaultConfig {
        applicationId = "es.elorrieta.app.firebaseempresas"
        minSdk = 30
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // -- NOTA -- //
    // Por motivos que se me escapan, los tarados de Firebase han dejado de sacar nuevas versiones
    // de los módulos KTX y han quitado las librerias KTX de Firebase Android BoM (v34.0.0).
    // Por tanto, si NO pones la 33.0.0, no tendrás ningún error de Gradle, pero en la MainActivity
    // no te deja importar la librería "FirebaseFirestore" para la siguiente linea:
    // private val db = FirebaseFirestore.getInstance().
    // Por qué? Porque no se la descarga porque no la tiene. para la sversiones 34.0.0 y superiores
    // Y qué forma hay que usar entonces? Su API. Pero como el cambio lo han hecho en Julio del 2025
    // Hay que apañarse con una versión anterior...

    // Import the Firebase BoM
    implementation(platform("com.google.firebase:firebase-bom:33.0.0"))

    // Firestore KTX (para Kotlin)
    implementation("com.google.firebase:firebase-firestore-ktx")

    // Now you can add the dependencies for Firebase products you want to use
    // When using the BoM, don't specify versions in Firebase dependencies
    //implementation(libs.firebase.analytics) // Optional
    implementation("com.google.firebase:firebase-analytics") // Optional

}