package com.elorrieta.pruebasfirebase.fiireBaseDataBase.pojo

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class Alumno(val id: Integer?, val nombre: String? = null, val apellido: String? = null) {
    // Null default values create a no-argument default constructor, which is needed
    // for deserialization from a DataSnapshot.
}