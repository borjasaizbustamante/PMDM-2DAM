package com.elorrieta.pruebasfirebase

import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.elorrieta.pruebasfirebase.fiireBaseDataBase.pojo.Alumno
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    // Database reference
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.button).setOnClickListener {
            try {
                // We get the database reference, the 'root' of the hierarchy
                database = Firebase.database.reference
                // We get the data
                database.child("T_ALUMNOS").orderByChild("id")
                    .get().addOnSuccessListener { alumno ->
                    val myList = findViewById<ListView>(R.id.listView)
                    val list = arrayListOf<Alumno>()
                    if (null != alumno){
                        // We iterate the students...
                        for (alum in alumno.children) {
                            // We create the POJO
                            val al = Alumno(alum.child("id").getValue(Integer::class.java),
                                alum.child("name").getValue(String::class.java),
                                alum.child("surname").getValue(String::class.java))
                            // Add to the list
                            list.add(al)
                        }
                        // Load the ListView
                        val adapter = ArrayAdapter (this, android.R.layout.simple_list_item_1, list)
                        myList.adapter = adapter
                    } else {
                        Log.e("firebase", "No data")
                    }
                }.addOnFailureListener{
                    Log.e("firebase", "Error getting data", it)
                }
            } catch (e: Exception) {
                // Something went wrong
                Log.e("exception", e.localizedMessage)
            }
        }
    }
}